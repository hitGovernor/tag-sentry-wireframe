// TagSentry — Background Service Worker (MV3)
import {
  identifyVendor, parseUrlForVendor, decodePostBody,
  scanForPII, extractEventName, getEffectivePIIPatterns,
  parseWebSdkBody,
} from './vendors.js';

// ── STATE ──────────────────────────────────────────────────────
// Per-tab live session data (in-memory; cleared on SW restart — expected).
const liveSessions  = new Map(); // tabId → Session
const pendingBodies = new Map(); // requestId → string

// ── SIDE PANEL ─────────────────────────────────────────────────
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// ── CAPTURE REQUEST BODIES ─────────────────────────────────────
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (!details.requestBody) return;
    try {
      if (details.requestBody.raw) {
        const chunks = details.requestBody.raw
          .map(r => r.bytes ? new Uint8Array(r.bytes) : new Uint8Array());
        const total  = chunks.reduce((n, c) => n + c.length, 0);
        const merged = new Uint8Array(total);
        let off = 0;
        chunks.forEach(c => { merged.set(c, off); off += c.length; });
        pendingBodies.set(details.requestId, new TextDecoder().decode(merged));
      } else if (details.requestBody.formData) {
        const fd = {};
        for (const [k, v] of Object.entries(details.requestBody.formData)) {
          fd[k] = Array.isArray(v) && v.length === 1 ? v[0] : v;
        }
        pendingBodies.set(details.requestId, JSON.stringify(fd));
      }
    } catch (_) {}
  },
  { urls: ['<all_urls>'] },
  ['requestBody']
);

// ── PROCESS REDIRECTS (3xx) ────────────────────────────────────
// onCompleted only fires for the *final* response. onBeforeRedirect fires
// whenever the server sends a 3xx, giving us visibility into redirect chains
// (tracking pixels, impression beacons, etc.) that never reach onCompleted.
chrome.webRequest.onBeforeRedirect.addListener(
  async (details) => {
    const { tabId, requestId, url, method, statusCode, type } = details;
    if (tabId < 0) return;

    // Reuse body if captured (rare for redirects but possible for POST→GET)
    const rawBody = pendingBodies.get(requestId) || null;
    // Do NOT delete from pendingBodies — the redirected request reuses the id

    await processRequest({
      tabId, requestId, url, method,
      statusCode: statusCode || 302,
      type, rawBody,
      isRedirect: true,
    });
  },
  { urls: ['<all_urls>'] }
);

// ── PROCESS COMPLETED REQUESTS ─────────────────────────────────
chrome.webRequest.onCompleted.addListener(
  async (details) => {
    const { tabId, requestId, url, method, statusCode, type } = details;
    if (tabId < 0) return;

    const rawBody = pendingBodies.get(requestId) || null;
    pendingBodies.delete(requestId);

    await processRequest({ tabId, requestId, url, method, statusCode, type, rawBody, isRedirect: false });
  },
  { urls: ['<all_urls>'] }
);

// ── SHARED REQUEST PROCESSOR ───────────────────────────────────
async function processRequest({ tabId, requestId, url, method, statusCode, type, rawBody, isRedirect }) {
  // Check recording state
  let store;
  try {
    store = await chrome.storage.session.get([`rec_${tabId}`, 'gSettings']);
  } catch (_) { return; }

  const isRecording = store[`rec_${tabId}`] !== false;
  if (!isRecording) return;

  const settings  = store.gSettings || {};
  let local;
  try {
    local = await chrome.storage.local.get(['whitelist', 'customVendors', 'exclusions']);
  } catch (_) { return; }

  const whitelist  = local.whitelist     || {};
  const custom     = local.customVendors || [];
  const exclusions = local.exclusions    || {};

  const vendor = identifyVendor(url, custom);
  if (!vendor && settings.knownVendorsOnly) return;

  // Respect exclusion list — if vendor is excluded, skip entirely
  if (vendor && exclusions[vendor.id] === true) return;
  // For unknown vendors, check hostname-based exclusions
  if (!vendor) {
    try {
      const host = new URL(url).hostname;
      if (exclusions[`host:${host}`] === true) return;
    } catch (_) {}
  }

  const params  = parseUrlForVendor(url, vendor?.id || null);
  let   bodyObj = rawBody ? decodePostBody(rawBody) : {};

  // Adobe Web SDK: the POST body is an XDM envelope.  Run the dedicated
  // flattener so individual event fields are scannable for PII and visible
  // in the detail panel without the user having to expand nested JSON.
  if (vendor?.id === 'adobe_websdk' && bodyObj && typeof bodyObj === 'object') {
    bodyObj = parseWebSdkBody(bodyObj);
  }

  const allParams = { ...params, ...(typeof bodyObj === 'object' ? bodyObj : {}) };

  // PII enablement rules (evaluated at request-capture time):
  //   undefined → settings not yet loaded (SW cold start) → treat as all-on
  //   null      → legacy sentinel meaning "never configured" → treat as all-on
  //   []        → user explicitly disabled all patterns → scan nothing
  //   [...ids]  → user's saved selection → scan only those ids
  //
  // We use ALL_PII_IDS as the fallback so that a cold-start SW (where
  // gSettings hasn't been written to session storage yet) still scans
  // rather than silently dropping all findings.
  const rawPII     = settings.piiPatterns;
  const enabledPII = (rawPII === undefined || rawPII === null) ? ALL_PII_IDS : rawPII;
  const customPatterns = settings.customPiiPatterns || [];
  const piiFindings    = scanForPII(allParams, enabledPII, customPatterns);

  // Allow-list status:
  // - known vendor with whitelist entry === false → not whitelisted (Unlisted)
  // - known vendor with no entry or entry === true → whitelisted
  // - unknown vendor → not whitelisted
  const isWhitelisted = vendor ? (whitelist[vendor.id] !== false) : false;

  const entry = {
    id:          `r_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp:   Date.now(),
    url,
    hostname:    safeHostname(url),
    method:      method || 'GET',
    statusCode:  statusCode || 0,
    type,
    isRedirect:  !!isRedirect,
    vendor:      vendor
      ? { id: vendor.id, name: vendor.name, category: vendor.category,
          icon: vendor.icon, iconBg: vendor.iconBg, iconColor: vendor.iconColor }
      : null,
    eventName:   extractEventName(vendor, params, bodyObj),
    params,
    bodyParams:  typeof bodyObj === 'object' ? bodyObj : { _raw: rawBody },
    rawUrl:      url,
    piiFindings,
    isWhitelisted,
    isKnown:     !!vendor,
  };

  // Store in live session
  let session = liveSessions.get(tabId);
  if (!session) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    session = {
      tabId,
      startTime: Date.now(),
      pageUrl:   tab?.url || '',
      requests:  [],
      piiCount:  0,
    };
    liveSessions.set(tabId, session);
  }
  session.requests.push(entry);
  session.piiCount += piiFindings.length;

  updateBadge(tabId, session);

  // Broadcast to side panel (may not be open)
  chrome.runtime.sendMessage({ type: 'NEW_REQUEST', tabId, entry }).catch(() => {});
}

// ── BADGE ──────────────────────────────────────────────────────
function updateBadge(tabId, session) {
  try {
    if (session.piiCount > 0) {
      chrome.action.setBadgeText({ text: '!', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444', tabId });
    } else {
      const n = session.requests.length;
      chrome.action.setBadgeText({ text: n > 99 ? '99+' : String(n), tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#5b6ef5', tabId });
    }
  } catch (_) {}
}

// ── TAB LIFECYCLE ──────────────────────────────────────────────
chrome.tabs.onRemoved.addListener((tabId) => {
  liveSessions.delete(tabId);
  // Clean up per-tab recording flag from session storage (best-effort)
  chrome.storage.session.remove([`rec_${tabId}`]).catch(() => {});
  // Clear badge (tab is gone but avoids stale badge state on restore)
  chrome.action.setBadgeText({ text: '', tabId }).catch(() => {});
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== 'loading') return;
  let gSettings;
  try {
    const d = await chrome.storage.session.get('gSettings');
    gSettings = d.gSettings;
  } catch (_) { return; }
  if ((gSettings || {}).clearOnNavigate) {
    liveSessions.delete(tabId);
    chrome.action.setBadgeText({ text: '', tabId }).catch(() => {});
  }
});

// ── MESSAGE BUS ────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  handleMsg(msg).then(respond).catch(e => respond({ error: e.message }));
  return true; // keep channel open for async response
});

async function handleMsg(msg) {
  switch (msg.type) {

    case 'GET_LIVE_SESSION': {
      return { session: liveSessions.get(msg.tabId) || null };
    }

    case 'CLEAR_LIVE_SESSION': {
      liveSessions.delete(msg.tabId);
      chrome.action.setBadgeText({ text: '', tabId: msg.tabId }).catch(() => {});
      return { ok: true };
    }

    case 'SET_RECORDING': {
      await chrome.storage.session.set({ [`rec_${msg.tabId}`]: msg.value });
      if (!msg.value) chrome.action.setBadgeText({ text: '', tabId: msg.tabId }).catch(() => {});
      return { ok: true };
    }

    case 'GET_RECORDING': {
      const d = await chrome.storage.session.get([`rec_${msg.tabId}`]);
      return { recording: d[`rec_${msg.tabId}`] !== false };
    }

    case 'SAVE_SESSION': {
      const live = liveSessions.get(msg.tabId);
      if (!live || !live.requests.length) return { ok: false, error: 'No requests to save' };

      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const gd = await chrome.storage.session.get('gSettings').catch(() => ({}));
      const max = (gd.gSettings || {}).maxSessions || 50;

      const saved = {
        ...live,
        id:           `s_${Date.now()}`,
        name:         msg.name || `Session — ${new Date().toLocaleString()}`,
        savedAt:      Date.now(),
        requestCount: live.requests.length,
        piiCount:     live.piiCount || 0,
        vendorIds:    [...new Set(live.requests.map(r => r.vendor?.id).filter(Boolean))],
      };

      const updated = [saved, ...sessions].slice(0, max);
      await chrome.storage.local.set({ sessions: updated });
      if (msg.setBaseline) await chrome.storage.local.set({ baselineId: saved.id });
      return { ok: true, session: saved };
    }

    case 'GET_SESSIONS': {
      const { sessions = [], baselineId = null } =
        await chrome.storage.local.get(['sessions', 'baselineId']);
      return { sessions, baselineId };
    }

    case 'DELETE_SESSION': {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      await chrome.storage.local.set({ sessions: sessions.filter(s => s.id !== msg.id) });
      return { ok: true };
    }

    case 'SET_BASELINE': {
      await chrome.storage.local.set({ baselineId: msg.id });
      return { ok: true };
    }

    case 'DIFF_SESSIONS': {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const a = sessions.find(s => s.id === msg.idA);
      const b = sessions.find(s => s.id === msg.idB);
      if (!a) return { error: 'Session A not found' };
      if (!b) return { error: 'Session B not found' };
      return { diff: computeDiff(a, b) };
    }

    case 'GET_SETTINGS': {
      const d = await chrome.storage.local.get(
        ['settings', 'whitelist', 'customVendors', 'exclusions', 'vendorOverrides']
      );
      return {
        settings:       d.settings       || defaultSettings(),
        whitelist:      d.whitelist      || {},
        customVendors:  d.customVendors  || [],
        exclusions:     d.exclusions     || {},
        vendorOverrides:d.vendorOverrides || {},
      };
    }

    case 'SAVE_SETTINGS': {
      if (msg.settings)       await chrome.storage.local.set({ settings:       msg.settings });
      if (msg.whitelist)      await chrome.storage.local.set({ whitelist:      msg.whitelist });
      if (msg.customVendors)  await chrome.storage.local.set({ customVendors:  msg.customVendors });
      if (msg.exclusions  !== undefined)
                              await chrome.storage.local.set({ exclusions:     msg.exclusions });
      if (msg.vendorOverrides !== undefined)
                              await chrome.storage.local.set({ vendorOverrides: msg.vendorOverrides });

      // Sync active settings to session store so onCompleted picks up immediately
      const { settings } = await chrome.storage.local.get('settings');
      await chrome.storage.session.set({ gSettings: settings || defaultSettings() });
      return { ok: true };
    }

    case 'CLEAR_ALL_DATA': {
      await chrome.storage.local.clear();
      await chrome.storage.session.clear();
      liveSessions.clear();
      return { ok: true };
    }

    case 'BACKUP': {
      const d = await chrome.storage.local.get(null);
      return { backup: JSON.stringify(d, null, 2) };
    }

    case 'RESTORE': {
      try {
        const data = JSON.parse(msg.json);
        await chrome.storage.local.clear();
        await chrome.storage.local.set(data);
        const { settings } = await chrome.storage.local.get('settings');
        await chrome.storage.session.set({ gSettings: settings || defaultSettings() });
        return { ok: true };
      } catch (e) { return { error: e.message }; }
    }

    default:
      return { error: `Unknown message type: ${msg.type}` };
  }
}

// ── DIFF ENGINE ────────────────────────────────────────────────
function computeDiff(sessA, sessB) {
  const aMap = groupByVendor(sessA.requests || []);
  const bMap = groupByVendor(sessB.requests || []);
  const keys  = new Set([...Object.keys(aMap), ...Object.keys(bMap)]);
  const changes = [];

  for (const key of keys) {
    const inA = !!aMap[key], inB = !!bMap[key];
    if (inA && !inB) {
      changes.push({
        type:       'removed',
        key,
        vendorName: aMap[key][0]?.vendor?.name || key,
        category:   aMap[key][0]?.vendor?.category || '',
        hostname:   aMap[key][0]?.hostname || '',
      });
    } else if (!inA && inB) {
      changes.push({
        type:          'added',
        key,
        vendorName:    bMap[key][0]?.vendor?.name || key,
        category:      bMap[key][0]?.vendor?.category || '',
        hostname:      bMap[key][0]?.hostname || '',
        isWhitelisted: bMap[key][0]?.isWhitelisted,
        isKnown:       bMap[key][0]?.isKnown,
      });
    } else {
      const pd = diffParams(aMap[key][0]?.params || {}, bMap[key][0]?.params || {});
      if (pd.length) {
        changes.push({
          type:       'changed',
          key,
          vendorName: aMap[key][0]?.vendor?.name || key,
          category:   aMap[key][0]?.vendor?.category || '',
          paramDiff:  pd,
        });
      }
    }
  }

  return {
    sessionA: { id: sessA.id, name: sessA.name, url: sessA.pageUrl, count: sessA.requests?.length || 0 },
    sessionB: { id: sessB.id, name: sessB.name, url: sessB.pageUrl, count: sessB.requests?.length || 0 },
    changes,
    summary: {
      removed: changes.filter(c => c.type === 'removed').length,
      added:   changes.filter(c => c.type === 'added').length,
      changed: changes.filter(c => c.type === 'changed').length,
    },
  };
}

function groupByVendor(requests) {
  const map = {};
  for (const r of requests) {
    const k = r.vendor?.id || r.hostname;
    if (!map[k]) map[k] = [];
    map[k].push(r);
  }
  return map;
}

function diffParams(a, b) {
  const out  = [];
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const k of keys) {
    if (!(k in b))   out.push({ key: k, type: 'removed', old: a[k] });
    else if (!(k in a)) out.push({ key: k, type: 'added', nw: b[k] });
    else if (String(a[k]) !== String(b[k]))
      out.push({ key: k, type: 'changed', old: a[k], nw: b[k] });
  }
  return out;
}

// ── HELPERS ────────────────────────────────────────────────────
function safeHostname(url) {
  try { return new URL(url).hostname; } catch { return url.slice(0, 80); }
}

// ── PII PATTERN IDS ────────────────────────────────────────────
// All built-in pattern ids in priority order.  Used to populate the
// "all enabled" default and to validate incoming settings.
const ALL_PII_IDS = ['email', 'phone', 'ssn', 'cc', 'ip', 'dob'];

function defaultSettings() {
  return {
    autoStart:         true,
    knownVendorsOnly:  false,
    clearOnNavigate:   false,
    maxSessions:       50,
    // null  = sentinel meaning "never been configured" → treat as all-on
    // []    = user explicitly disabled all patterns
    // [...] = user's explicit selection
    // We store null here so the init block below can detect first install.
    piiPatterns:       null,
    customPiiPatterns: [],
  };
}

// ── INIT: sync settings to session store on SW start ──────────
// On a fresh install chrome.storage.local has no 'settings' key at all.
// We detect that and write the all-on default so the user sees PII working
// immediately without having to visit Settings.
(async () => {
  try {
    const stored = await chrome.storage.local.get('settings');

    let settings;
    if (!stored.settings) {
      // First install — write explicit all-on defaults so both the SW and
      // the panel see the same value and the Settings UI shows all checked.
      settings = { ...defaultSettings(), piiPatterns: ALL_PII_IDS };
      await chrome.storage.local.set({ settings });
    } else {
      settings = stored.settings;
      // Migrate: if an older build stored null (meaning "not yet set"),
      // upgrade silently to all-on so existing users don't lose PII scanning.
      if (settings.piiPatterns === null) {
        settings = { ...settings, piiPatterns: ALL_PII_IDS };
        await chrome.storage.local.set({ settings });
      }
    }

    await chrome.storage.session.set({ gSettings: settings });
  } catch (_) {}
})();
