// TagSentry — Vendor Pattern Library & PII Detection
// Exported as ES module, imported by background.js

export const VENDORS = [
  // ── ANALYTICS ──────────────────────────────────────
  { id:'ga4',        name:'Google Analytics 4',           category:'Analytics',     icon:'G4',  iconBg:'#e8f0fe', iconColor:'#1a73e8',
    patterns:[/google-analytics\.com\/g\/collect/i, /analytics\.google\.com\/g\/collect/i, /google-analytics\.com\/mp\/collect/i] },

  { id:'ua',         name:'Universal Analytics',          category:'Analytics',     icon:'UA',  iconBg:'#c8e0fc', iconColor:'#1a73e8',
    patterns:[/google-analytics\.com\/collect/i, /stats\.g\.doubleclick\.net\/r\/collect/i] },

  { id:'adobe_aa',   name:'Adobe Analytics',              category:'Analytics',     icon:'Aa',  iconBg:'#fff0e8', iconColor:'#e8760a',
    patterns:[/\/b\/ss\//i, /omtrdc\.net/i, /2o7\.net/i, /sc\.omtrdc\.net/i] },

  { id:'mixpanel',   name:'Mixpanel',                     category:'Analytics',     icon:'Mx',  iconBg:'#f5e8ff', iconColor:'#7c3aed',
    patterns:[/api\.mixpanel\.com/i, /mixpanel\.com\/track/i] },

  { id:'amplitude',  name:'Amplitude',                    category:'Analytics',     icon:'Am',  iconBg:'#fff4e8', iconColor:'#ff6b35',
    patterns:[/api\.amplitude\.com/i, /api2\.amplitude\.com/i] },

  { id:'segment',    name:'Segment',                      category:'Analytics',     icon:'Sg',  iconBg:'#e8fff0', iconColor:'#52b043',
    patterns:[/api\.segment\.io/i, /api\.segment\.com/i, /cdn\.segment\.com/i] },

  { id:'heap',       name:'Heap',                         category:'Analytics',     icon:'Hp',  iconBg:'#ffe8f0', iconColor:'#e8407a',
    patterns:[/heapanalytics\.com/i] },

  { id:'matomo',     name:'Matomo / Piwik',               category:'Analytics',     icon:'Mt',  iconBg:'#e8f0ff', iconColor:'#3d5af1',
    patterns:[/matomo\.php/i, /piwik\.php/i, /piwik\.pro/i] },

  { id:'fullstory',  name:'FullStory',                    category:'Analytics',     icon:'Fs',  iconBg:'#e8fff8', iconColor:'#00b37a',
    patterns:[/fullstory\.com\/rec/i, /rs\.fullstory\.com/i, /edge\.fullstory\.com/i] },

  { id:'rudderstack',name:'RudderStack',                  category:'Analytics',     icon:'Rs',  iconBg:'#ffe8e8', iconColor:'#cc3c3c',
    patterns:[/dataplane\.rudderstack\.com/i, /rudderstack\.com/i] },

  { id:'posthog',    name:'PostHog',                      category:'Analytics',     icon:'Ph',  iconBg:'#fff4e8', iconColor:'#f76707',
    patterns:[/app\.posthog\.com/i, /eu\.posthog\.com/i] },

  { id:'pendo',      name:'Pendo',                        category:'Analytics',     icon:'Pe',  iconBg:'#e8f5ff', iconColor:'#0066cc',
    patterns:[/app\.pendo\.io/i, /cdn\.pendo\.io/i, /data\.pendo\.io/i] },

  // ── ADVERTISING ────────────────────────────────────
  { id:'meta_pixel', name:'Meta Pixel',                   category:'Advertising',   icon:'fb',  iconBg:'#e8f0ff', iconColor:'#0866ff',
    patterns:[/facebook\.com\/tr\b/i, /connect\.facebook\.net\/signals/i] },

  { id:'tiktok',     name:'TikTok Pixel',                 category:'Advertising',   icon:'Tk',  iconBg:'#111', iconColor:'#fe2c55',
    patterns:[/analytics\.tiktok\.com/i, /business\.tiktok\.com\/api/i] },

  { id:'google_ads', name:'Google Ads',                   category:'Advertising',   icon:'GA',  iconBg:'#fffbe8', iconColor:'#e37400',
    patterns:[/googleadservices\.com\/pagead\/conversion/i, /google\.com\/pagead\/ga-audiences/i] },

  { id:'dv360',      name:'Display & Video 360',          category:'Advertising',   icon:'DV',  iconBg:'#e8f0fe', iconColor:'#1a73e8',
    patterns:[/fls\.doubleclick\.net/i, /ad\.doubleclick\.net/i, /googleads\.g\.doubleclick\.net/i] },

  { id:'linkedin',   name:'LinkedIn Insight Tag',         category:'Advertising',   icon:'in',  iconBg:'#e8f4ff', iconColor:'#0a66c2',
    patterns:[/snap\.licdn\.com/i, /px\.ads\.linkedin\.com/i] },

  { id:'twitter_x',  name:'X (Twitter) Pixel',            category:'Advertising',   icon:'X',   iconBg:'#f0f0f0', iconColor:'#000',
    patterns:[/static\.ads-twitter\.com/i, /analytics\.twitter\.com\/i\//i, /t\.co\/i\/adsct/i] },

  { id:'pinterest',  name:'Pinterest Tag',                category:'Advertising',   icon:'P',   iconBg:'#ffe8e8', iconColor:'#e60023',
    patterns:[/ct\.pinterest\.com/i, /trk\.pinterest\.com/i] },

  { id:'snapchat',   name:'Snapchat Pixel',               category:'Advertising',   icon:'Sc',  iconBg:'#fffae8', iconColor:'#b8930f',
    patterns:[/tr\.snapchat\.com/i, /sc-static\.net/i] },

  { id:'bing_uet',   name:'Microsoft / Bing UET',         category:'Advertising',   icon:'Bi',  iconBg:'#e8f0ff', iconColor:'#0067b8',
    patterns:[/bat\.bing\.com/i, /clarity\.ms\/collect/i] },

  { id:'criteo',     name:'Criteo',                       category:'Advertising',   icon:'Cr',  iconBg:'#ffe8e0', iconColor:'#f1551e',
    patterns:[/dis\.criteo\.com/i, /sslwidget\.criteo\.com/i, /static\.criteo\.net/i] },

  { id:'taboola',    name:'Taboola',                      category:'Advertising',   icon:'Tb',  iconBg:'#fff8f0', iconColor:'#e8820c',
    patterns:[/trc\.taboola\.com/i, /cdn\.taboola\.com/i] },

  { id:'outbrain',   name:'Outbrain',                     category:'Advertising',   icon:'Ob',  iconBg:'#fff0f5', iconColor:'#cc2255',
    patterns:[/tr\.outbrain\.com/i, /amplify\.outbrain\.com/i] },

  { id:'reddit_ads', name:'Reddit Pixel',                 category:'Advertising',   icon:'Re',  iconBg:'#ffe8e0', iconColor:'#ff4500',
    patterns:[/alb\.reddit\.com/i, /rdt\.reddit\.com/i] },

  // ── TAG MANAGEMENT ─────────────────────────────────
  { id:'gtm',        name:'Google Tag Manager',           category:'Tag Mgmt',      icon:'GTM', iconBg:'#e8fee8', iconColor:'#1a73e8',
    patterns:[/googletagmanager\.com\/gtm\.js/i, /googletagmanager\.com\/ns\.html/i] },

  { id:'tealium_iq', name:'Tealium iQ',                   category:'Tag Mgmt',      icon:'TiQ', iconBg:'#e8fff8', iconColor:'#00a86b',
    patterns:[/tags\.tiqcdn\.com/i, /tealiumiq\.com/i] },

  { id:'adobe_dtm',  name:'Adobe Experience Platform Tags',category:'Tag Mgmt',     icon:'AEP', iconBg:'#fff0e8', iconColor:'#e8760a',
    patterns:[/assets\.adobedtm\.com/i, /launch\.adobe\.net/i] },

  { id:'ensighten',  name:'Ensighten',                    category:'Tag Mgmt',      icon:'En',  iconBg:'#e8f0ff', iconColor:'#3a5bd9',
    patterns:[/nexus\.ensighten\.com/i] },

  // ── CONSENT ────────────────────────────────────────
  { id:'onetrust',   name:'OneTrust CMP',                 category:'Consent',       icon:'OT',  iconBg:'#e8f5ea', iconColor:'#007a33',
    patterns:[/cdn\.cookielaw\.org/i, /onetrust\.com/i] },

  { id:'cookiebot',  name:'Cookiebot',                    category:'Consent',       icon:'Cb',  iconBg:'#e8f4e8', iconColor:'#2e7d32',
    patterns:[/consent\.cookiebot\.com/i, /cookiebotcdn\.com/i] },

  { id:'trustarc',   name:'TrustArc',                     category:'Consent',       icon:'Ta',  iconBg:'#e8e8ff', iconColor:'#4040cc',
    patterns:[/consent\.trustarc\.com/i, /truste\.com/i] },

  { id:'usercentrics',name:'Usercentrics',                category:'Consent',       icon:'Uc',  iconBg:'#f0e8ff', iconColor:'#7c3aed',
    patterns:[/app\.usercentrics\.eu/i, /api\.usercentrics\.eu/i] },

  { id:'didomi',     name:'Didomi',                       category:'Consent',       icon:'Di',  iconBg:'#e8f5ff', iconColor:'#0099e6',
    patterns:[/sdk\.privacy-center\.org/i, /didomi\.io/i] },

  // ── A/B TESTING ────────────────────────────────────
  { id:'optimizely', name:'Optimizely',                   category:'A/B Testing',   icon:'Op',  iconBg:'#fff0e8', iconColor:'#f66a0a',
    patterns:[/cdn\.optimizely\.com/i, /logx\.optimizely\.com/i] },

  { id:'vwo',        name:'VWO',                          category:'A/B Testing',   icon:'VW',  iconBg:'#e8f8ff', iconColor:'#0088cc',
    patterns:[/dev\.visualwebsiteoptimizer\.com/i, /vwo\.com/i] },

  { id:'abtasty',    name:'AB Tasty',                     category:'A/B Testing',   icon:'AB',  iconBg:'#ffe8f5', iconColor:'#d63384',
    patterns:[/abtasty\.com/i, /client-data\.abtasty\.com/i] },

  // ── HEATMAPS ───────────────────────────────────────
  { id:'hotjar',     name:'Hotjar',                       category:'Heatmaps',      icon:'Hj',  iconBg:'#fff0e8', iconColor:'#fd3a5c',
    patterns:[/static\.hotjar\.com/i, /vc\.hotjar\.io/i, /insights\.hotjar\.com/i] },

  { id:'clarity',    name:'Microsoft Clarity',            category:'Heatmaps',      icon:'Cl',  iconBg:'#e8f0ff', iconColor:'#0067b8',
    patterns:[/clarity\.ms/i] },

  { id:'mouseflow',  name:'Mouseflow',                    category:'Heatmaps',      icon:'Mf',  iconBg:'#ffe8e8', iconColor:'#e63c3c',
    patterns:[/mouseflow\.com/i] },

  { id:'lucky_orange',name:'Lucky Orange',                category:'Heatmaps',      icon:'Lo',  iconBg:'#fff8e8', iconColor:'#e8820c',
    patterns:[/luckyorange\.com/i, /luckyorange\.net/i] },

  // ── CDP ────────────────────────────────────────────
  { id:'tealium_as', name:'Tealium AudienceStream',       category:'CDP',           icon:'TAS', iconBg:'#e8fff8', iconColor:'#00a86b',
    patterns:[/visitor-service\.tealiumiq\.com/i, /collect\.tealiumiq\.com/i] },

  { id:'klaviyo',    name:'Klaviyo',                      category:'CDP',           icon:'Kl',  iconBg:'#f5f0ff', iconColor:'#6b46c1',
    patterns:[/a\.klaviyo\.com/i, /static\.klaviyo\.com/i] },

  { id:'braze',      name:'Braze',                        category:'CDP',           icon:'Br',  iconBg:'#fff0f5', iconColor:'#cc2255',
    patterns:[/braze\.com\/api/i, /sdk\.iad-\d+\.braze\.com/i] },

  { id:'lytics',     name:'Lytics',                       category:'CDP',           icon:'Ly',  iconBg:'#e8f5ff', iconColor:'#0066aa',
    patterns:[/c\.lytics\.io/i, /api\.lytics\.io/i] },
];

// ── PII PATTERNS ───────────────────────────────────────────────
// Industry-standard patterns with proper word boundaries and context guards.
// Each regex is anchored and specific to avoid false positives.
//
// Email:  RFC 5322 simplified — requires TLD, rejects bare local parts
// Phone:  NANP (North American Numbering Plan) — E.164 or common US formats,
//         requires full 10-digit number, anchored by word boundaries
// SSN:    IRS/SSA format — 3-2-4 digit groups with dash or space,
//         excludes invalid ranges (000, 666, 9xx area numbers)
// CC:     Luhn-structure patterns for Visa/MC/Amex/Discover/JCB,
//         must be at a word boundary to avoid matching numeric IDs
// IP:     Valid IPv4 only (excludes localhost 127.x and private ranges optional)
// DOB:    ISO 8601 (YYYY-MM-DD) and common US (MM/DD/YYYY) formats, year 1900–2099

export const PII_PATTERNS = [
  {
    id:       'email',
    name:     'Email Address',
    severity: 'HIGH',
    // Must have localpart@domain.tld, TLD 2-24 chars, rejects consecutive dots
    regex: /\b[a-zA-Z0-9](?:[a-zA-Z0-9._%+\-]{0,62}[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,24})+\b/,
    description: 'Email address (RFC 5322 simplified)',
  },
  {
    id:       'phone',
    name:     'US Phone Number',
    severity: 'HIGH',
    // NANP: optional +1 or 1 country code, then NXX-NXX-XXXX
    // N = digit 2-9, X = digit 0-9. Accepts dashes, dots, spaces, parens.
    // Must be preceded and followed by non-digit to avoid false positives in long numbers
    regex: /(?<![\d])(?:\+?1[\s.\-]?)?(?:\([2-9]\d{2}\)|[2-9]\d{2})[\s.\-]?[2-9]\d{2}[\s.\-]?\d{4}(?![\d])/,
    description: 'US/Canada phone (NANP): (NXX) NXX-XXXX or +1NXXNXXXXXX',
  },
  {
    id:       'ssn',
    name:     'SSN (US Social Security Number)',
    severity: 'HIGH',
    // SSA format: AAA-GG-SSSS. Area (AAA) excludes 000, 666, 900-999.
    // Group (GG) excludes 00. Serial (SSSS) excludes 0000.
    // Two variants: with separator (dash or space) or without (9-digit run).
    regex: /\b(?!000|666|9\d{2})[0-8]\d{2}-(?!00)\d{2}-(?!0000)\d{4}\b|\b(?!000|666|9\d{2})[0-8]\d{2} (?!00)\d{2} (?!0000)\d{4}\b|\b(?!000|666|9\d{2})[0-8]\d{2}(?!00)\d{2}(?!0000)\d{4}\b/,
    description: 'SSN: AAA-GG-SSSS (excludes known-invalid area/group/serial numbers)',
  },
  {
    id:       'cc',
    name:     'Credit/Debit Card Number',
    severity: 'HIGH',
    // Covers Visa (13/16d), Mastercard (16d), Amex (15d), Discover (16d), JCB (16d)
    // Requires word boundary — won't match inside longer numeric strings
    // Optional spaces/dashes between groups (common display format)
    regex: /\b(?:4[0-9]{3}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{1,4}|5[1-5][0-9]{2}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}|3[47][0-9]{2}[\s\-]?[0-9]{6}[\s\-]?[0-9]{5}|6(?:011|5[0-9]{2})[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}|(?:2131|1800|35\d{3})[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{3})\b/,
    description: 'Credit/debit card (Visa/MC/Amex/Discover/JCB)',
  },
  {
    id:       'ip',
    name:     'IP Address (IPv4)',
    severity: 'MEDIUM',
    // Valid IPv4 (each octet 0-255), anchored — excludes 0.0.0.0 and 255.255.255.255
    // Does NOT flag 127.x or private ranges (analytics may legitimately log server IPs)
    regex: /\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\b/,
    description: 'IPv4 address (valid range, excludes 0.0.0.0 and broadcast)',
  },
  {
    id:       'dob',
    name:     'Date of Birth',
    severity: 'MEDIUM',
    // ISO 8601: YYYY-MM-DD (year 1900–2024) and US MM/DD/YYYY, month/day range validated
    regex: /\b(?:19[0-9]{2}|20[0-1][0-9]|202[0-4])[-\/](0[1-9]|1[0-2])[-\/](0[1-9]|[12]\d|3[01])\b|\b(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(19[0-9]{2}|20[0-1][0-9]|202[0-4])\b/,
    description: 'Date of birth: YYYY-MM-DD or MM/DD/YYYY (1900–2024)',
  },
];

// Returns PII_PATTERNS merged with any custom patterns from settings
export function getEffectivePIIPatterns(customPatterns) {
  if (!customPatterns || !customPatterns.length) return PII_PATTERNS;
  const builtinIds = new Set(PII_PATTERNS.map(p => p.id));
  const customs = customPatterns
    .filter(p => p.id && p.pattern)
    .map(p => {
      try {
        return {
          id:          p.id,
          name:        p.name || p.id,
          severity:    p.severity || 'MEDIUM',
          regex:       new RegExp(p.pattern, p.flags || 'i'),
          description: p.description || '',
          isCustom:    true,
        };
      } catch { return null; }
    })
    .filter(Boolean);
  // Custom patterns with same id as builtins override them
  const overridden = new Set(customs.filter(p => builtinIds.has(p.id)).map(p => p.id));
  const base = PII_PATTERNS.filter(p => !overridden.has(p.id));
  return [...base, ...customs];
}

// ── VENDOR MATCHER ─────────────────────────────────────────────
export function identifyVendor(url, customVendors = []) {
  const all = [...VENDORS, ...customVendors];
  for (const v of all) {
    const patterns = v.patterns || [];
    for (const p of patterns) {
      const re = typeof p === 'string' ? new RegExp(p, 'i') : p;
      try { if (re.test(url)) return v; } catch (_) {}
    }
  }
  return null;
}

// ── QUERY PARAM PARSER ─────────────────────────────────────────
export function parseQueryParams(url) {
  try {
    const u = new URL(url);
    const out = {};
    u.searchParams.forEach((v, k) => { out[k] = v; });
    return out;
  } catch { return {}; }
}

// ── POST BODY DECODER ──────────────────────────────────────────
export function decodePostBody(raw) {
  if (!raw) return {};
  // Try JSON
  try { const j = JSON.parse(raw); if (j && typeof j === 'object') return j; } catch {}
  // Try URL-encoded
  try {
    const out = {};
    const dec = decodeURIComponent(raw.replace(/\+/g, ' '));
    dec.split('&').forEach(pair => {
      const i = pair.indexOf('=');
      if (i > 0) out[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
    });
    if (Object.keys(out).length) return out;
  } catch {}
  // Return raw snippet
  return { _raw: raw.slice(0, 600) };
}

// ── PII SCANNER ────────────────────────────────────────────────
export function scanForPII(paramObj, enabledIds, customPatterns) {
  const findings = [];
  const effective = getEffectivePIIPatterns(customPatterns);
  const patterns = enabledIds
    ? effective.filter(p => enabledIds.includes(p.id))
    : effective;

  function checkVal(key, val) {
    if (typeof val !== 'string' && typeof val !== 'number') return;
    const s = String(val);
    if (s.length < 4 || s.length > 500) return;
    for (const p of patterns) {
      if (p.regex.test(s)) {
        findings.push({ param: key, value: s, patternId: p.id, patternName: p.name, severity: p.severity });
        break; // one finding per param
      }
    }
  }

  function walk(obj, prefix) {
    if (!obj || typeof obj !== 'object') { checkVal(prefix, obj); return; }
    for (const [k, v] of Object.entries(obj)) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) walk(v, key);
      else checkVal(key, v);
    }
  }
  walk(paramObj, '');
  return findings;
}

// ── EVENT NAME EXTRACTOR ───────────────────────────────────────
export function extractEventName(vendor, params, body) {
  const all = { ...params, ...(body && typeof body === 'object' ? body : {}) };
  if (!vendor) return all.event || all.action || all.t || '';
  switch (vendor.id) {
    case 'ga4':        return all.en || 'collect';
    case 'ua':         return all.t  || 'pageview';
    case 'meta_pixel': return all.ev || all.event || 'unknown';
    case 'adobe_aa':   return all.pe ? `link:${all.pev2 || ''}` : 'pageview';
    case 'tiktok':
      try { return JSON.parse(all.data)?.[0]?.event || 'collect'; } catch { return 'collect'; }
    default:           return all.event || all.action || all.en || all.t || 'collect';
  }
}
