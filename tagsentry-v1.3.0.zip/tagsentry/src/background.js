// TagSentry — Background Service Worker (MV3)
import {
  identifyVendor, parseQueryParams, decodePostBody,
  scanForPII, extractEventName, getEffectivePIIPatterns
} from './vendors.js';

// ── STATE ──────────────────────────────────────────────────────
// Per-tab live session data (in-memory, lost on SW restart — that's fine)
const liveSessions = new Map();   // tabId → Session
const pendingBodies = new Map();  // requestId → string

// ── SIDE PANEL: open on toolbar click ─────────────────────────
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// ── CAPTURE REQUEST BODIES ─────────────────────────────────────
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (!details.requestBody) return;
    try {
      if (details.requestBody.raw) {
        const chunks = details.requestBody.raw
          .map(r => r.bytes ? new Uint8Array(r.bytes) : new Uint8Array());
        const total = chunks.reduce((n, c) => n + c.length, 0);
        const merged = new Uint8Array(total);
        let off = 0;
        chunks.forEach(c => { merged.set(c, off); off += c.length; });
        pendingBodies.set(details.requestId, new TextDecoder().decode(merged));
      } else if (details.requestBody.formData) {
        const fd = {};
        for (const [k, v] of Object.entries(details.requestBody.formData)) {
          fd[k] = Array.isArray(v) && v.length === 1 ? v[0] : v;
        }
        pendingBodies.set(details.requestId, JSON.stringify(fd));
      }
    } catch (_) {}
  },
  { urls: ['<all_urls>'] },
  ['requestBody']
);

// ── PROCESS COMPLETED REQUESTS ─────────────────────────────────
chrome.webRequest.onCompleted.addListener(
  async (details) => {
    const { tabId, requestId, url, method, statusCode, type } = details;
    if (tabId < 0) return;

    const rawBody = pendingBodies.get(requestId) || null;
    pendingBodies.delete(requestId);

    // Check recording state + settings
    const store = await chrome.storage.session.get([`rec_${tabId}`, 'gSettings']);
    const isRecording = store[`rec_${tabId}`] !== false;
    if (!isRecording) return;

    const settings  = store.gSettings || {};
    const local     = await chrome.storage.local.get(['whitelist', 'customVendors']);
    const whitelist = local.whitelist     || {};
    const custom    = local.customVendors || [];

    const vendor    = identifyVendor(url, custom);
    if (!vendor && settings.knownVendorsOnly) return;

    const params    = parseQueryParams(url);
    const bodyObj   = rawBody ? decodePostBody(rawBody) : {};
    const allParams = { ...params, ...(typeof bodyObj === 'object' ? bodyObj : {}) };

    const enabledPII     = settings.piiPatterns   || null;
    const customPatterns = settings.customPiiPatterns || [];
    const piiFindings    = scanForPII(allParams, enabledPII, customPatterns);

    const isWhitelisted = vendor ? (whitelist[vendor.id] !== false) : false;

    const entry = {
      id:        `r_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
      timestamp: Date.now(),
      url,
      hostname:  safeHostname(url),
      method:    method || 'GET',
      statusCode: statusCode || 0,
      type,
      vendor:    vendor
        ? { id: vendor.id, name: vendor.name, category: vendor.category,
            icon: vendor.icon, iconBg: vendor.iconBg, iconColor: vendor.iconColor }
        : null,
      eventName:   extractEventName(vendor, params, bodyObj),
      params,
      bodyParams:  typeof bodyObj === 'object' ? bodyObj : { _raw: rawBody },
      rawUrl:      url,
      piiFindings,
      isWhitelisted,
      isKnown: !!vendor,
    };

    // Store
    let session = liveSessions.get(tabId);
    if (!session) {
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      session = { tabId, startTime: Date.now(), pageUrl: tab?.url || '', requests: [], piiCount: 0 };
      liveSessions.set(tabId, session);
    }
    session.requests.push(entry);
    session.piiCount += piiFindings.length;

    updateBadge(tabId, session);

    // Broadcast to side panel (may not be open — that's OK)
    chrome.runtime.sendMessage({ type: 'NEW_REQUEST', tabId, entry }).catch(() => {});
  },
  { urls: ['<all_urls>'] }
);

// ── BADGE ──────────────────────────────────────────────────────
function updateBadge(tabId, session) {
  if (session.piiCount > 0) {
    chrome.action.setBadgeText({ text: '!', tabId });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444', tabId });
  } else {
    const n = session.requests.length;
    chrome.action.setBadgeText({ text: n > 99 ? '99+' : String(n), tabId });
    chrome.action.setBadgeBackgroundColor({ color: '#5b6ef5', tabId });
  }
}

// ── TAB LIFECYCLE ──────────────────────────────────────────────
chrome.tabs.onRemoved.addListener((tabId) => { liveSessions.delete(tabId); });

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== 'loading') return;
  const { gSettings } = await chrome.storage.session.get('gSettings');
  if ((gSettings || {}).clearOnNavigate) {
    liveSessions.delete(tabId);
    chrome.action.setBadgeText({ text: '', tabId });
  }
});

// ── MESSAGE BUS ────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  handleMsg(msg).then(respond).catch(e => respond({ error: e.message }));
  return true; // keep channel open
});

async function handleMsg(msg) {
  switch (msg.type) {

    case 'GET_LIVE_SESSION': {
      return { session: liveSessions.get(msg.tabId) || null };
    }

    case 'CLEAR_LIVE_SESSION': {
      liveSessions.delete(msg.tabId);
      chrome.action.setBadgeText({ text: '', tabId: msg.tabId });
      return { ok: true };
    }

    case 'SET_RECORDING': {
      await chrome.storage.session.set({ [`rec_${msg.tabId}`]: msg.value });
      if (!msg.value) chrome.action.setBadgeText({ text: '', tabId: msg.tabId });
      return { ok: true };
    }

    case 'GET_RECORDING': {
      const d = await chrome.storage.session.get([`rec_${msg.tabId}`]);
      return { recording: d[`rec_${msg.tabId}`] !== false };
    }

    case 'SAVE_SESSION': {
      const live = liveSessions.get(msg.tabId);
      if (!live || !live.requests.length) return { ok: false, error: 'No requests to save' };
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const { gSettings }    = await chrome.storage.session.get('gSettings');
      const max = (gSettings || {}).maxSessions || 50;
      const saved = {
        ...live,
        id:      `s_${Date.now()}`,
        name:    msg.name || `Session ${new Date().toLocaleString()}`,
        savedAt: Date.now(),
        requestCount: live.requests.length,
        vendorIds: [...new Set(live.requests.map(r => r.vendor?.id).filter(Boolean))],
      };
      const updated = [saved, ...sessions].slice(0, max);
      await chrome.storage.local.set({ sessions: updated });
      if (msg.setBaseline) await chrome.storage.local.set({ baselineId: saved.id });
      return { ok: true, session: saved };
    }

    case 'GET_SESSIONS': {
      const { sessions = [], baselineId = null } = await chrome.storage.local.get(['sessions','baselineId']);
      return { sessions, baselineId };
    }

    case 'DELETE_SESSION': {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      await chrome.storage.local.set({ sessions: sessions.filter(s => s.id !== msg.id) });
      return { ok: true };
    }

    case 'SET_BASELINE': {
      await chrome.storage.local.set({ baselineId: msg.id });
      return { ok: true };
    }

    case 'DIFF_SESSIONS': {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const a = sessions.find(s => s.id === msg.idA);
      const b = sessions.find(s => s.id === msg.idB);
      if (!a) return { error: 'Session A not found' };
      if (!b) return { error: 'Session B not found' };
      return { diff: computeDiff(a, b) };
    }

    case 'GET_SETTINGS': {
      const d = await chrome.storage.local.get(['settings','whitelist','customVendors']);
      return {
        settings:      d.settings      || defaultSettings(),
        whitelist:     d.whitelist     || {},
        customVendors: d.customVendors || [],
      };
    }

    case 'SAVE_SETTINGS': {
      if (msg.settings)      await chrome.storage.local.set({ settings: msg.settings });
      if (msg.whitelist)     await chrome.storage.local.set({ whitelist: msg.whitelist });
      if (msg.customVendors) await chrome.storage.local.set({ customVendors: msg.customVendors });
      // Push to session store so onCompleted picks up changes immediately
      const { settings } = await chrome.storage.local.get('settings');
      await chrome.storage.session.set({ gSettings: settings || defaultSettings() });
      return { ok: true };
    }

    case 'CLEAR_ALL_DATA': {
      await chrome.storage.local.clear();
      await chrome.storage.session.clear();
      liveSessions.clear();
      return { ok: true };
    }

    case 'BACKUP': {
      const d = await chrome.storage.local.get(null);
      return { backup: JSON.stringify(d, null, 2) };
    }

    case 'RESTORE': {
      try {
        const data = JSON.parse(msg.json);
        await chrome.storage.local.clear();
        await chrome.storage.local.set(data);
        const { settings } = await chrome.storage.local.get('settings');
        await chrome.storage.session.set({ gSettings: settings || defaultSettings() });
        return { ok: true };
      } catch (e) { return { error: e.message }; }
    }

    default:
      return { error: `Unknown message type: ${msg.type}` };
  }
}

// ── DIFF ENGINE ────────────────────────────────────────────────
function computeDiff(sessA, sessB) {
  const aMap = groupByVendor(sessA.requests || []);
  const bMap = groupByVendor(sessB.requests || []);
  const keys = new Set([...Object.keys(aMap), ...Object.keys(bMap)]);
  const changes = [];

  for (const key of keys) {
    const inA = !!aMap[key], inB = !!bMap[key];
    if (inA && !inB) {
      changes.push({
        type: 'removed',
        key,
        vendorName: aMap[key][0]?.vendor?.name || key,
        category:   aMap[key][0]?.vendor?.category || '',
        hostname:   aMap[key][0]?.hostname || '',
      });
    } else if (!inA && inB) {
      changes.push({
        type: 'added',
        key,
        vendorName:   bMap[key][0]?.vendor?.name || key,
        category:     bMap[key][0]?.vendor?.category || '',
        hostname:     bMap[key][0]?.hostname || '',
        isWhitelisted: bMap[key][0]?.isWhitelisted,
        isKnown:       bMap[key][0]?.isKnown,
      });
    } else {
      // Both present — diff params of first matching request
      const pd = diffParams(
        aMap[key][0]?.params || {},
        bMap[key][0]?.params || {}
      );
      if (pd.length) {
        changes.push({
          type: 'changed',
          key,
          vendorName: aMap[key][0]?.vendor?.name || key,
          category:   aMap[key][0]?.vendor?.category || '',
          paramDiff: pd,
        });
      }
    }
  }

  return {
    sessionA: { id: sessA.id, name: sessA.name, url: sessA.pageUrl, count: sessA.requests?.length || 0 },
    sessionB: { id: sessB.id, name: sessB.name, url: sessB.pageUrl, count: sessB.requests?.length || 0 },
    changes,
    summary: {
      removed: changes.filter(c => c.type === 'removed').length,
      added:   changes.filter(c => c.type === 'added').length,
      changed: changes.filter(c => c.type === 'changed').length,
    },
  };
}

function groupByVendor(requests) {
  const map = {};
  for (const r of requests) {
    const k = r.vendor?.id || r.hostname;
    if (!map[k]) map[k] = [];
    map[k].push(r);
  }
  return map;
}

function diffParams(a, b) {
  const out = [];
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const k of keys) {
    if (!(k in b))    out.push({ key: k, type: 'removed', old: a[k] });
    else if (!(k in a)) out.push({ key: k, type: 'added',   nw: b[k] });
    else if (String(a[k]) !== String(b[k]))
      out.push({ key: k, type: 'changed', old: a[k], nw: b[k] });
  }
  return out;
}

// ── HELPERS ────────────────────────────────────────────────────
function safeHostname(url) {
  try { return new URL(url).hostname; } catch { return url.slice(0, 80); }
}

function defaultSettings() {
  return {
    autoStart:       true,
    knownVendorsOnly: false,
    clearOnNavigate: false,
    maxSessions:     50,
    piiPatterns:     null, // null = all enabled
  };
}

// ── INIT: push default settings to session store on SW start ───
(async () => {
  const { settings } = await chrome.storage.local.get('settings');
  await chrome.storage.session.set({ gSettings: settings || defaultSettings() });
})();
