// TagSentry — Content Script
// Runs in the extension's isolated world; injects injected.js into the page world
(function () {
  'use strict';

  // Inject the page-context script to intercept dataLayer
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('src/injected.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);

  // Listen for postMessage from injected.js and relay to background
  window.addEventListener('message', (e) => {
    if (!e.data || e.data.__ts !== 'tagsentry') return;

    // dataLayer events
    if (e.data.payload?.source === 'dataLayer') {
      chrome.runtime.sendMessage({
        type: 'DATALAYER_PUSH',
        payload: e.data.payload,
      }).catch(() => {});
      return;
    }

    // Console errors / window.onerror / unhandledrejection
    if (e.data.type === 'page_error') {
      chrome.runtime.sendMessage({
        type:    'PAGE_ERROR',
        payload: e.data.payload,
        // Attach the page hostname so background can key errors to requests
        hostname: location.hostname,
      }).catch(() => {});
    }
  });
})();
