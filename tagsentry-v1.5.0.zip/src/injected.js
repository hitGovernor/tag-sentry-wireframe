// TagSentry — Injected Script (runs in PAGE context, not extension context)
// Intercepts window.dataLayer.push to capture GTM events
// Also captures console.error, window.onerror, and unhandledrejection
(function () {
  'use strict';

  // ── dataLayer intercept ────────────────────────────────────────
  function patch() {
    if (!window.dataLayer) window.dataLayer = [];
    if (window.dataLayer.__ts_patched) return;
    window.dataLayer.__ts_patched = true;

    const _push = window.dataLayer.push.bind(window.dataLayer);
    window.dataLayer.push = function (...args) {
      for (const item of args) {
        if (item && typeof item === 'object') {
          try {
            window.postMessage({
              __ts: 'tagsentry',
              payload: {
                source: 'dataLayer',
                event: item.event || '(no event)',
                data: JSON.parse(JSON.stringify(item)),
                ts: Date.now(),
              },
            }, '*');
          } catch (_) {}
        }
      }
      return _push(...args);
    };
  }

  // Patch immediately and re-check for late dataLayer init
  patch();
  let tries = 0;
  const iv = setInterval(() => { patch(); if (++tries > 20) clearInterval(iv); }, 500);

  // ── Console error capture ──────────────────────────────────────
  // Override console.error in the page world to capture errors.
  // We store the original and call it so normal dev-tools behaviour is preserved.
  const _consoleError = console.error.bind(console);
  console.error = function (...args) {
    try {
      const message = args.map(a => {
        if (typeof a === 'string') return a;
        try { return JSON.stringify(a); } catch { return String(a); }
      }).join(' ');
      window.postMessage({
        __ts:    'tagsentry',
        type:    'page_error',
        payload: { source: 'console.error', message, ts: Date.now() },
      }, '*');
    } catch (_) {}
    return _consoleError(...args);
  };

  // ── window.onerror capture ─────────────────────────────────────
  const _prevOnerror = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    try {
      window.postMessage({
        __ts:    'tagsentry',
        type:    'page_error',
        payload: {
          source:  'window.onerror',
          message: String(message),
          file:    source   ? String(source)  : undefined,
          line:    lineno   ? Number(lineno)  : undefined,
          col:     colno    ? Number(colno)   : undefined,
          stack:   error?.stack ? String(error.stack) : undefined,
          ts: Date.now(),
        },
      }, '*');
    } catch (_) {}
    if (typeof _prevOnerror === 'function') return _prevOnerror.apply(this, arguments);
    return false; // let default handling proceed
  };

  // ── unhandledrejection capture ─────────────────────────────────
  window.addEventListener('unhandledrejection', (e) => {
    try {
      const reason = e.reason;
      const message = reason instanceof Error
        ? reason.message
        : (typeof reason === 'string' ? reason : JSON.stringify(reason));
      window.postMessage({
        __ts:    'tagsentry',
        type:    'page_error',
        payload: {
          source:  'unhandledrejection',
          message: message || '(empty rejection)',
          stack:   reason?.stack ? String(reason.stack) : undefined,
          ts: Date.now(),
        },
      }, '*');
    } catch (_) {}
  });

})();
