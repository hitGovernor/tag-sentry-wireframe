// TagSentry — Injected Script (runs in PAGE context, not extension context)
// Intercepts window.dataLayer.push to capture GTM events
(function () {
  'use strict';

  function patch() {
    if (!window.dataLayer) window.dataLayer = [];
    if (window.dataLayer.__ts_patched) return;
    window.dataLayer.__ts_patched = true;

    const _push = window.dataLayer.push.bind(window.dataLayer);
    window.dataLayer.push = function (...args) {
      for (const item of args) {
        if (item && typeof item === 'object') {
          try {
            window.postMessage({
              __ts: 'tagsentry',
              payload: {
                source: 'dataLayer',
                event: item.event || '(no event)',
                data: JSON.parse(JSON.stringify(item)),
                ts: Date.now(),
              },
            }, '*');
          } catch (_) {}
        }
      }
      return _push(...args);
    };
  }

  // Patch immediately and re-check for late dataLayer init
  patch();
  let tries = 0;
  const iv = setInterval(() => { patch(); if (++tries > 20) clearInterval(iv); }, 500);
})();
