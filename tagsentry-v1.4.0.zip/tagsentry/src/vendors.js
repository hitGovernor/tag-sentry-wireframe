// TagSentry — Vendor Pattern Library & PII Detection
// Exported as ES module, imported by background.js

export const VENDORS = [
  // ── ANALYTICS ──────────────────────────────────────
  { id:'ga4',        name:'Google Analytics 4',           category:'Analytics',     icon:'G4',  iconBg:'#e8f0fe', iconColor:'#1a73e8',
    patterns:[/google-analytics\.com\/g\/collect/i, /analytics\.google\.com\/g\/collect/i, /google-analytics\.com\/mp\/collect/i] },

  { id:'ua',         name:'Universal Analytics',          category:'Analytics',     icon:'UA',  iconBg:'#c8e0fc', iconColor:'#1a73e8',
    patterns:[/google-analytics\.com\/collect/i, /stats\.g\.doubleclick\.net\/r\/collect/i] },

  { id:'adobe_aa',   name:'Adobe Analytics',              category:'Analytics',     icon:'Aa',  iconBg:'#fff0e8', iconColor:'#e8760a',
    patterns:[/\/b\/ss\//i, /omtrdc\.net/i, /2o7\.net/i, /sc\.omtrdc\.net/i] },

  { id:'mixpanel',   name:'Mixpanel',                     category:'Analytics',     icon:'Mx',  iconBg:'#f5e8ff', iconColor:'#7c3aed',
    patterns:[/api\.mixpanel\.com/i, /mixpanel\.com\/track/i] },

  { id:'amplitude',  name:'Amplitude',                    category:'Analytics',     icon:'Am',  iconBg:'#fff4e8', iconColor:'#ff6b35',
    patterns:[/api\.amplitude\.com/i, /api2\.amplitude\.com/i] },

  { id:'segment',    name:'Segment',                      category:'Analytics',     icon:'Sg',  iconBg:'#e8fff0', iconColor:'#52b043',
    patterns:[/api\.segment\.io/i, /api\.segment\.com/i, /cdn\.segment\.com/i] },

  { id:'heap',       name:'Heap',                         category:'Analytics',     icon:'Hp',  iconBg:'#ffe8f0', iconColor:'#e8407a',
    patterns:[/heapanalytics\.com/i] },

  { id:'matomo',     name:'Matomo / Piwik',               category:'Analytics',     icon:'Mt',  iconBg:'#e8f0ff', iconColor:'#3d5af1',
    patterns:[/matomo\.php/i, /piwik\.php/i, /piwik\.pro/i] },

  { id:'fullstory',  name:'FullStory',                    category:'Analytics',     icon:'Fs',  iconBg:'#e8fff8', iconColor:'#00b37a',
    patterns:[/fullstory\.com\/rec/i, /rs\.fullstory\.com/i, /edge\.fullstory\.com/i] },

  { id:'rudderstack',name:'RudderStack',                  category:'Analytics',     icon:'Rs',  iconBg:'#ffe8e8', iconColor:'#cc3c3c',
    patterns:[/dataplane\.rudderstack\.com/i, /rudderstack\.com/i] },

  { id:'posthog',    name:'PostHog',                      category:'Analytics',     icon:'Ph',  iconBg:'#fff4e8', iconColor:'#f76707',
    patterns:[/app\.posthog\.com/i, /eu\.posthog\.com/i] },

  { id:'pendo',      name:'Pendo',                        category:'Analytics',     icon:'Pe',  iconBg:'#e8f5ff', iconColor:'#0066cc',
    patterns:[/app\.pendo\.io/i, /cdn\.pendo\.io/i, /data\.pendo\.io/i] },

  // ── ADVERTISING ────────────────────────────────────
  { id:'meta_pixel', name:'Meta Pixel',                   category:'Advertising',   icon:'fb',  iconBg:'#e8f0ff', iconColor:'#0866ff',
    patterns:[/facebook\.com\/tr\b/i, /connect\.facebook\.net\/signals/i] },

  { id:'tiktok',     name:'TikTok Pixel',                 category:'Advertising',   icon:'Tk',  iconBg:'#111', iconColor:'#fe2c55',
    patterns:[/analytics\.tiktok\.com/i, /business\.tiktok\.com\/api/i] },

  { id:'google_ads', name:'Google Ads',                   category:'Advertising',   icon:'GA',  iconBg:'#fffbe8', iconColor:'#e37400',
    patterns:[/googleadservices\.com\/pagead\/conversion/i, /google\.com\/pagead\/ga-audiences/i, /googleadservices\.com\/pagead\/viewthroughconversion/i] },

  { id:'dv360',      name:'Display & Video 360',          category:'Advertising',   icon:'DV',  iconBg:'#e8f0fe', iconColor:'#1a73e8',
    patterns:[/fls\.doubleclick\.net/i, /ad\.doubleclick\.net/i, /googleads\.g\.doubleclick\.net/i] },

  { id:'linkedin',   name:'LinkedIn Insight Tag',         category:'Advertising',   icon:'in',  iconBg:'#e8f4ff', iconColor:'#0a66c2',
    patterns:[/snap\.licdn\.com/i, /px\.ads\.linkedin\.com/i] },

  { id:'twitter_x',  name:'X (Twitter) Pixel',            category:'Advertising',   icon:'X',   iconBg:'#f0f0f0', iconColor:'#000',
    patterns:[/static\.ads-twitter\.com/i, /analytics\.twitter\.com\/i\//i, /t\.co\/i\/adsct/i] },

  { id:'pinterest',  name:'Pinterest Tag',                category:'Advertising',   icon:'P',   iconBg:'#ffe8e8', iconColor:'#e60023',
    patterns:[/ct\.pinterest\.com/i, /trk\.pinterest\.com/i] },

  { id:'snapchat',   name:'Snapchat Pixel',               category:'Advertising',   icon:'Sc',  iconBg:'#fffae8', iconColor:'#b8930f',
    patterns:[/tr\.snapchat\.com/i, /sc-static\.net/i] },

  { id:'bing_uet',   name:'Microsoft / Bing UET',         category:'Advertising',   icon:'Bi',  iconBg:'#e8f0ff', iconColor:'#0067b8',
    patterns:[/bat\.bing\.com/i, /clarity\.ms\/collect/i] },

  { id:'criteo',     name:'Criteo',                       category:'Advertising',   icon:'Cr',  iconBg:'#ffe8e0', iconColor:'#f1551e',
    patterns:[/dis\.criteo\.com/i, /sslwidget\.criteo\.com/i, /static\.criteo\.net/i] },

  { id:'taboola',    name:'Taboola',                      category:'Advertising',   icon:'Tb',  iconBg:'#fff8f0', iconColor:'#e8820c',
    patterns:[/trc\.taboola\.com/i, /cdn\.taboola\.com/i] },

  { id:'outbrain',   name:'Outbrain',                     category:'Advertising',   icon:'Ob',  iconBg:'#fff0f5', iconColor:'#cc2255',
    patterns:[/tr\.outbrain\.com/i, /amplify\.outbrain\.com/i] },

  { id:'reddit_ads', name:'Reddit Pixel',                 category:'Advertising',   icon:'Re',  iconBg:'#ffe8e0', iconColor:'#ff4500',
    patterns:[/alb\.reddit\.com/i, /rdt\.reddit\.com/i] },

  // ── TAG MANAGEMENT ─────────────────────────────────
  { id:'gtm',        name:'Google Tag Manager',           category:'Tag Mgmt',      icon:'GTM', iconBg:'#e8fee8', iconColor:'#1a73e8',
    patterns:[/googletagmanager\.com\/gtm\.js/i, /googletagmanager\.com\/ns\.html/i] },

  { id:'tealium_iq', name:'Tealium iQ',                   category:'Tag Mgmt',      icon:'TiQ', iconBg:'#e8fff8', iconColor:'#00a86b',
    patterns:[/tags\.tiqcdn\.com/i, /tealiumiq\.com/i] },

  { id:'adobe_dtm',  name:'Adobe Experience Platform Tags',category:'Tag Mgmt',     icon:'AEP', iconBg:'#fff0e8', iconColor:'#e8760a',
    patterns:[/assets\.adobedtm\.com/i, /launch\.adobe\.net/i] },

  { id:'ensighten',  name:'Ensighten',                    category:'Tag Mgmt',      icon:'En',  iconBg:'#e8f0ff', iconColor:'#3a5bd9',
    patterns:[/nexus\.ensighten\.com/i] },

  // ── CONSENT ────────────────────────────────────────
  { id:'onetrust',   name:'OneTrust CMP',                 category:'Consent',       icon:'OT',  iconBg:'#e8f5ea', iconColor:'#007a33',
    patterns:[/cdn\.cookielaw\.org/i, /onetrust\.com/i] },

  { id:'cookiebot',  name:'Cookiebot',                    category:'Consent',       icon:'Cb',  iconBg:'#e8f4e8', iconColor:'#2e7d32',
    patterns:[/consent\.cookiebot\.com/i, /cookiebotcdn\.com/i] },

  { id:'trustarc',   name:'TrustArc',                     category:'Consent',       icon:'Ta',  iconBg:'#e8e8ff', iconColor:'#4040cc',
    patterns:[/consent\.trustarc\.com/i, /truste\.com/i] },

  { id:'usercentrics',name:'Usercentrics',                category:'Consent',       icon:'Uc',  iconBg:'#f0e8ff', iconColor:'#7c3aed',
    patterns:[/app\.usercentrics\.eu/i, /api\.usercentrics\.eu/i] },

  { id:'didomi',     name:'Didomi',                       category:'Consent',       icon:'Di',  iconBg:'#e8f5ff', iconColor:'#0099e6',
    patterns:[/sdk\.privacy-center\.org/i, /didomi\.io/i] },

  // ── A/B TESTING ────────────────────────────────────
  { id:'optimizely', name:'Optimizely',                   category:'A/B Testing',   icon:'Op',  iconBg:'#fff0e8', iconColor:'#f66a0a',
    patterns:[/cdn\.optimizely\.com/i, /logx\.optimizely\.com/i] },

  { id:'vwo',        name:'VWO',                          category:'A/B Testing',   icon:'VW',  iconBg:'#e8f8ff', iconColor:'#0088cc',
    patterns:[/dev\.visualwebsiteoptimizer\.com/i, /vwo\.com/i] },

  { id:'abtasty',    name:'AB Tasty',                     category:'A/B Testing',   icon:'AB',  iconBg:'#ffe8f5', iconColor:'#d63384',
    patterns:[/abtasty\.com/i, /client-data\.abtasty\.com/i] },

  // ── HEATMAPS ───────────────────────────────────────
  { id:'hotjar',     name:'Hotjar',                       category:'Heatmaps',      icon:'Hj',  iconBg:'#fff0e8', iconColor:'#fd3a5c',
    patterns:[/static\.hotjar\.com/i, /vc\.hotjar\.io/i, /insights\.hotjar\.com/i] },

  { id:'clarity',    name:'Microsoft Clarity',            category:'Heatmaps',      icon:'Cl',  iconBg:'#e8f0ff', iconColor:'#0067b8',
    patterns:[/clarity\.ms/i] },

  { id:'mouseflow',  name:'Mouseflow',                    category:'Heatmaps',      icon:'Mf',  iconBg:'#ffe8e8', iconColor:'#e63c3c',
    patterns:[/mouseflow\.com/i] },

  { id:'lucky_orange',name:'Lucky Orange',                category:'Heatmaps',      icon:'Lo',  iconBg:'#fff8e8', iconColor:'#e8820c',
    patterns:[/luckyorange\.com/i, /luckyorange\.net/i] },

  // ── CDP ────────────────────────────────────────────
  { id:'tealium_as', name:'Tealium AudienceStream',       category:'CDP',           icon:'TAS', iconBg:'#e8fff8', iconColor:'#00a86b',
    patterns:[/visitor-service\.tealiumiq\.com/i, /collect\.tealiumiq\.com/i] },

  { id:'klaviyo',    name:'Klaviyo',                      category:'CDP',           icon:'Kl',  iconBg:'#f5f0ff', iconColor:'#6b46c1',
    patterns:[/a\.klaviyo\.com/i, /static\.klaviyo\.com/i] },

  { id:'braze',      name:'Braze',                        category:'CDP',           icon:'Br',  iconBg:'#fff0f5', iconColor:'#cc2255',
    patterns:[/braze\.com\/api/i, /sdk\.iad-\d+\.braze\.com/i] },

  { id:'lytics',     name:'Lytics',                       category:'CDP',           icon:'Ly',  iconBg:'#e8f5ff', iconColor:'#0066aa',
    patterns:[/c\.lytics\.io/i, /api\.lytics\.io/i] },
];

// ── PII PATTERNS ───────────────────────────────────────────────
// Phone pattern notes:
//   Analytics URLs are dense with multi-digit strings (timestamps, IDs, pixel
//   dimensions).  The phone pattern must require the 10-digit sequence is NOT
//   embedded inside a longer numeric run, AND is not preceded by URL-context
//   characters like '=', '/', '.', '%' which would indicate a numeric param
//   value rather than a phone number.
//
//   We use negative lookbehind for [\d=\/.%] and negative lookahead for \d.
//   Only full 10-digit NANP numbers match; 7-digit "local" numbers are excluded
//   because they are indistinguishable from timestamps and IDs in URL context.
//
//   SSN now requires separator characters (dash or space) between groups to
//   avoid false-positives on 9-digit numeric IDs which are common in URLs.

export const PII_PATTERNS = [
  {
    id:       'email',
    name:     'Email Address',
    severity: 'HIGH',
    regex: /\b[a-zA-Z0-9](?:[a-zA-Z0-9._%+\-]{0,62}[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,24})+\b/,
    description: 'Email address (RFC 5322 simplified)',
  },
  {
    id:       'phone',
    name:     'US Phone Number',
    severity: 'HIGH',
    // Negative lookbehind: not preceded by digit, =, /, ., % (URL context guard)
    // Negative lookahead:  not followed by digit (prevents matching inside longer IDs)
    // Requires full 10 NANP digits; first digit of area code and exchange must be 2-9
    regex: /(?<![\d=\/\.%])(?:\+?1[-.\s]?)?(?:\([2-9]\d{2}\)|[2-9]\d{2})[-.\s]?[2-9]\d{2}[-.\s]?\d{4}(?!\d)/,
    description: 'US/Canada phone (NANP, 10-digit full number only)',
  },
  {
    id:       'ssn',
    name:     'SSN (US Social Security Number)',
    severity: 'HIGH',
    // Requires dash or space separators — avoids false positives on 9-digit IDs
    regex: /\b(?!000|666|9\d{2})[0-8]\d{2}[-\s](?!00)\d{2}[-\s](?!0000)\d{4}\b/,
    description: 'SSN: AAA-GG-SSSS (separators required)',
  },
  {
    id:       'cc',
    name:     'Credit/Debit Card Number',
    severity: 'HIGH',
    regex: /\b(?:4[0-9]{3}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{1,4}|5[1-5][0-9]{2}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}|3[47][0-9]{2}[\s\-]?[0-9]{6}[\s\-]?[0-9]{5}|6(?:011|5[0-9]{2})[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}|(?:2131|1800|35\d{3})[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{3})\b/,
    description: 'Credit/debit card (Visa/MC/Amex/Discover/JCB)',
  },
  {
    id:       'ip',
    name:     'IP Address (IPv4)',
    severity: 'MEDIUM',
    regex: /\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\b/,
    description: 'IPv4 address (valid octet range)',
  },
  {
    id:       'dob',
    name:     'Date of Birth',
    severity: 'MEDIUM',
    regex: /\b(?:19[0-9]{2}|20[0-9]{2})[-\/](0[1-9]|1[0-2])[-\/](0[1-9]|[12]\d|3[01])\b|\b(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(19[0-9]{2}|20[0-9]{2})\b/,
    description: 'Date of birth: YYYY-MM-DD or MM/DD/YYYY',
  },
];

// ── PER-VENDOR URL PARSERS ─────────────────────────────────────
// Some vendors use non-standard query string delimiters or encodings.
// Each entry: (url: string) => object of {key: value} params, or null to
// fall back to standard URLSearchParams.
//
// Documented quirks handled here:
//
//  google_ads  — Floodlight tags use semicolons as both the query-string
//                opener and the parameter delimiter in the URL path:
//                /pagead/conversion/123456789/;src=shop;type=purchase;qty=1
//
//  dv360       — DoubleClick Floodlight uses the same semicolon path scheme.
//
//  adobe_aa    — /b/ss/{rsid}/{type}/{version}/... image requests. Path
//                segments carry metadata; real params are in the query string.
//                Also handles semicolons that trail the version segment.
//
//  bing_uet    — Standard query params plus an optional base64-encoded JSON
//                blob in the `b` parameter.
//
//  meta_pixel  — `data` param is URL-encoded JSON; flatten its fields so
//                PII scanner can inspect individual event properties.
//
//  tiktok      — `data` param is URL-encoded JSON array of event objects.
//
//  criteo      — Some pixels encode event data in /e/{base64} path segments.

const VENDOR_PARSERS = {

  google_ads(url) {
    const out = _stdParams(url);
    try {
      const path = new URL(url).pathname;
      const si = path.indexOf(';');
      if (si !== -1) _parseSemicolon(path.slice(si + 1), out);
    } catch (_) {}
    _parseFragment(url, out);
    return out;
  },

  dv360(url) {
    const out = _stdParams(url);
    try {
      const path = new URL(url).pathname;
      const si = path.indexOf(';');
      if (si !== -1) _parseSemicolon(path.slice(si + 1), out);
    } catch (_) {}
    _parseFragment(url, out);
    return out;
  },

  adobe_aa(url) {
    const out = _stdParams(url);
    try {
      const u     = new URL(url);
      const parts = u.pathname.split('/').filter(Boolean);
      // /b/ss/{rsid}/{type}/{version}/{pageId}
      if (parts[0] === 'b' && parts[1] === 'ss') {
        if (parts[2]) out['_rsid']    = parts[2];
        if (parts[3]) out['_hitType'] = parts[3];
        if (parts[4]) out['_version'] = parts[4];
        if (parts[5]) out['_pageId']  = parts[5];
      }
      const verPart = parts[4] || '';
      const si = verPart.indexOf(';');
      if (si !== -1) _parseSemicolon(verPart.slice(si + 1), out);
    } catch (_) {}
    return out;
  },

  bing_uet(url) {
    const out = _stdParams(url);
    if (out.b) {
      try {
        const decoded = JSON.parse(atob(out.b));
        if (decoded && typeof decoded === 'object') {
          for (const [k, v] of Object.entries(decoded)) {
            out[`b.${k}`] = typeof v === 'object' ? JSON.stringify(v) : String(v);
          }
        }
      } catch (_) {}
    }
    return out;
  },

  meta_pixel(url) {
    const out = _stdParams(url);
    if (out.data) {
      try {
        const decoded = JSON.parse(decodeURIComponent(out.data));
        if (decoded && typeof decoded === 'object') {
          _flattenInto(decoded, 'data', out);
        }
      } catch (_) {}
    }
    return out;
  },

  tiktok(url) {
    const out = _stdParams(url);
    if (out.data) {
      try {
        const arr   = JSON.parse(decodeURIComponent(out.data));
        const first = Array.isArray(arr) ? arr[0] : arr;
        if (first && typeof first === 'object') _flattenInto(first, 'data', out);
      } catch (_) {}
    }
    return out;
  },

  criteo(url) {
    const out = _stdParams(url);
    try {
      const parts = new URL(url).pathname.split('/').filter(Boolean);
      const ei    = parts.indexOf('e');
      if (ei !== -1 && parts[ei + 1]) {
        try {
          const decoded = JSON.parse(atob(parts[ei + 1]));
          if (decoded && typeof decoded === 'object') _flattenInto(decoded, 'e', out);
        } catch (_) {
          out['_e'] = parts[ei + 1];
        }
      }
    } catch (_) {}
    return out;
  },
};

// ── Internal parser helpers ────────────────────────────────────

function _stdParams(url) {
  try {
    const out = {};
    new URL(url).searchParams.forEach((v, k) => { out[k] = v; });
    return out;
  } catch { return {}; }
}

function _parseSemicolon(str, out) {
  str.split(';').forEach(pair => {
    const eq = pair.indexOf('=');
    if (eq > 0) {
      try {
        const k = decodeURIComponent(pair.slice(0, eq).trim());
        const v = decodeURIComponent(pair.slice(eq + 1).trim());
        if (k) out[k] = v;
      } catch (_) {}
    } else if (pair.trim()) {
      try { out[decodeURIComponent(pair.trim())] = '1'; } catch (_) {}
    }
  });
}

function _parseFragment(url, out) {
  try {
    const hash = new URL(url).hash.slice(1);
    if (!hash) return;
    hash.split('&').forEach(pair => {
      const eq = pair.indexOf('=');
      if (eq > 0) {
        out[`#${decodeURIComponent(pair.slice(0, eq))}`] = decodeURIComponent(pair.slice(eq + 1));
      }
    });
  } catch (_) {}
}

function _flattenInto(obj, prefix, out, depth = 0) {
  if (depth > 5) return;
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      _flattenInto(v, key, out, depth + 1);
    } else {
      out[key] = typeof v === 'object' ? JSON.stringify(v) : String(v ?? '');
    }
  }
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ── PUBLIC PARSER API ─────────────────────────────────────────
// Returns flat {key: value} params for a URL.
// Tries vendor-specific parser first, then standard URLSearchParams.
// vendorId: string id of identified vendor, or null.
export function parseUrlForVendor(url, vendorId) {
  if (vendorId && VENDOR_PARSERS[vendorId]) {
    try {
      const result = VENDOR_PARSERS[vendorId](url);
      if (result && typeof result === 'object') return result;
    } catch (_) {}
  }
  return _stdParams(url);
}

// Legacy alias — preserved for any direct callers.
export function parseQueryParams(url) {
  return _stdParams(url);
}

// ── VENDOR MATCHER ─────────────────────────────────────────────
// Custom vendors are checked first so they can extend or shadow builtins.
// Custom pattern strings: if the string starts with '/' it is compiled as a
// RegExp literal; otherwise treated as a case-insensitive substring pattern.
export function identifyVendor(url, customVendors = []) {
  const all = [...customVendors, ...VENDORS];
  for (const v of all) {
    const patterns = v.patterns || [];
    for (const p of patterns) {
      let re;
      if (typeof p === 'string') {
        if (p.startsWith('/')) {
          try {
            const last = p.lastIndexOf('/');
            re = new RegExp(p.slice(1, last), p.slice(last + 1) || 'i');
          } catch (_) { re = new RegExp(escapeRegExp(p), 'i'); }
        } else {
          re = new RegExp(escapeRegExp(p), 'i');
        }
      } else {
        re = p;
      }
      try { if (re.test(url)) return v; } catch (_) {}
    }
  }
  return null;
}

// ── POST BODY DECODER ──────────────────────────────────────────
export function decodePostBody(raw) {
  if (!raw) return {};
  try { const j = JSON.parse(raw); if (j && typeof j === 'object') return j; } catch {}
  try {
    const out = {};
    const dec = decodeURIComponent(raw.replace(/\+/g, ' '));
    dec.split('&').forEach(pair => {
      const i = pair.indexOf('=');
      if (i > 0) out[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
    });
    if (Object.keys(out).length) return out;
  } catch {}
  return { _raw: raw.slice(0, 600) };
}

// ── PII SCANNER ────────────────────────────────────────────────
// enabledIds: string[] of pattern ids to run.
//   - null  → all built-in + custom patterns run (legacy "all on" mode)
//   - []    → no patterns run (PII detection explicitly disabled)
//   - [ids] → only matching patterns run
export function scanForPII(paramObj, enabledIds, customPatterns) {
  const findings = [];

  // Empty array = PII detection OFF — return immediately
  if (Array.isArray(enabledIds) && enabledIds.length === 0) return findings;

  const effective = getEffectivePIIPatterns(customPatterns);
  const patterns  = enabledIds
    ? effective.filter(p => enabledIds.includes(p.id))
    : effective;

  if (!patterns.length) return findings;

  function checkVal(key, val) {
    if (typeof val !== 'string' && typeof val !== 'number') return;
    const s = String(val);
    if (s.length < 4 || s.length > 500) return;
    for (const p of patterns) {
      // Reset lastIndex for any stateful (global/sticky) regexes
      if (p.regex.global || p.regex.sticky) p.regex.lastIndex = 0;
      if (p.regex.test(s)) {
        findings.push({ param: key, value: s, patternId: p.id, patternName: p.name, severity: p.severity });
        break; // one finding per param — most specific pattern wins
      }
    }
  }

  function walk(obj, prefix, depth) {
    if (depth > 8) return;
    if (!obj || typeof obj !== 'object') { if (prefix) checkVal(prefix, obj); return; }
    for (const [k, v] of Object.entries(obj)) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (Array.isArray(v)) {
        v.forEach((item, i) => walk(item, `${key}[${i}]`, depth + 1));
      } else if (v && typeof v === 'object') {
        walk(v, key, depth + 1);
      } else {
        checkVal(key, v);
      }
    }
  }
  walk(paramObj, '', 0);
  return findings;
}

// Returns PII_PATTERNS merged with any custom patterns from settings.
// Custom patterns with the same id as a builtin override the builtin.
export function getEffectivePIIPatterns(customPatterns) {
  if (!customPatterns || !customPatterns.length) return PII_PATTERNS;
  const builtinIds = new Set(PII_PATTERNS.map(p => p.id));
  const customs = customPatterns
    .filter(p => p.id && p.pattern)
    .map(p => {
      try {
        return {
          id:          p.id,
          name:        p.name || p.id,
          severity:    p.severity || 'MEDIUM',
          regex:       new RegExp(p.pattern, p.flags || 'i'),
          description: p.description || '',
          isCustom:    true,
        };
      } catch { return null; }
    })
    .filter(Boolean);
  const overridden = new Set(customs.filter(p => builtinIds.has(p.id)).map(p => p.id));
  const base = PII_PATTERNS.filter(p => !overridden.has(p.id));
  return [...base, ...customs];
}

// ── EVENT NAME EXTRACTOR ───────────────────────────────────────
export function extractEventName(vendor, params, body) {
  const all = { ...params, ...(body && typeof body === 'object' ? body : {}) };
  if (!vendor) return all.event || all.action || all.t || '';
  switch (vendor.id) {
    case 'ga4':        return all.en || 'collect';
    case 'ua':         return all.t  || 'pageview';
    case 'meta_pixel': return all.ev || all.event || 'unknown';
    case 'adobe_aa':   return all.pe ? `link:${all.pev2 || ''}` : 'pageview';
    case 'tiktok':
      try { return JSON.parse(all.data)?.[0]?.event || 'collect'; } catch { return 'collect'; }
    case 'google_ads': return all.type || all.cat || all.label || 'conversion';
    case 'dv360':      return all.type || all.src  || 'floodlight';
    default:           return all.event || all.action || all.en || all.t || 'collect';
  }
}
