// TagSentry — Side Panel Controller
// Step 3: Live Tab (tab switching, recording, tag list, detail panel, stats, filters, save modal)

'use strict';

// ── STATE ──────────────────────────────────────────────────────
const state = {
  tabId:       null,
  recording:   true,
  requests:    [],       // all requests in live session
  filtered:    [],       // after filters applied
  selected:    null,     // selected request entry
  activeTab:   'live',   // panel tab
  activeDTab:  'params', // detail sub-tab (kept for compat, detail now shows all)
  kbIndex:     -1,       // keyboard navigation index in filtered list
  detailHeight: 300,     // detail panel height in px
  detailExpanded: false, // full-height mode
  filters: {
    text:      '',
    textRegex: null,     // compiled RegExp or null
    known:     false,
    pii:       false,
    warn:      false,
  },
  appearance: {
    theme: 'light',
    fontSize: 14,
  },
  // populated in later steps
  sessions:    [],
  baselineId:  null,
  whitelist:   {},
  exclusions:  {},        // vendorId → true means hide from Live feed entirely
  vendorOverrides: {},    // vendorId → { patterns: [...] } user overrides of builtin vendor defs
  customVendors: [],
  settings:    {},
  piiFilter: {
    search:   '',
    severity: null,   // null = all, 'HIGH'|'MEDIUM'|'LOW'
    vendor:   null,   // null = all, or vendor name string
  },
  clearGen: 0,        // incremented on clear to drop in-flight NEW_REQUEST messages
  tabCache:  new Map(), // tabId → { requests, filtered, selected, kbIndex } snapshot
};

// ── INIT ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await resolveTabId();
  initTabNav();
  // Settings MUST load before the live session renders so state.settings.piiPatterns
  // is populated — otherwise getVisiblePIIFindings() treats all patterns as enabled.
  await initSettingsTab();
  initAppearance();
  initCustomPiiPatterns();
  // Live tab
  initLiveTab();
  initSaveModal();
  await loadLiveSession();
  listenForNewRequests();
  // Remaining tabs
  await initSessionsTab();
  initDiffTab();
  initPIITab();
  await initAllowListTab();
  initExportTab();
  initKeyboardNav();
  initDetailResize();
  initTabAwareness();
});

async function resolveTabId() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      state.tabId = tabs?.[0]?.id ?? null;
      updateHeaderUrl(tabs?.[0]?.url ?? '');
      resolve();
    });
  });
}

function updateHeaderUrl(url) {
  const el = document.getElementById('headerUrl');
  if (!el) return;
  try { el.textContent = new URL(url).hostname; } catch { el.textContent = url.slice(0,40); }
}

// ── ACTIVE TAB AWARENESS ──────────────────────────────────────
// When the user switches browser tabs the panel reflects the new tab.
// We cache each tab's request list so switching back is instant and
// no data is lost — the list is tied to the tabId, not the domain.
function saveTabSnapshot() {
  if (!state.tabId) return;
  state.tabCache.set(state.tabId, {
    requests: [...state.requests],
    selected: state.selected,
    kbIndex:  state.kbIndex,
  });
}

function initTabAwareness() {
  chrome.tabs.onActivated.addListener(async ({ tabId }) => {
    if (tabId === state.tabId) return;

    // ── Save snapshot of the tab we're leaving ──
    saveTabSnapshot();

    const prevTabId = state.tabId;
    state.tabId   = tabId;
    state.kbIndex = -1;
    state.selected = null;

    // Update header URL immediately
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    updateHeaderUrl(tab?.url ?? '');

    hideDetail();

    // ── Restore cached snapshot if we've seen this tab before ──
    const cached = state.tabCache.get(tabId);
    if (cached) {
      state.requests = cached.requests;
      state.kbIndex  = cached.kbIndex ?? -1;
      // Don't restore selected — keep detail closed on tab switch
    } else {
      // First time seeing this tab — fetch from background
      state.requests = [];
      const res = await chrome.runtime.sendMessage({ type: 'GET_LIVE_SESSION', tabId });
      if (res?.session?.requests?.length) {
        state.requests = res.session.requests;
      }
    }

    state.filtered = [];
    applyFilters();
    updateStats();
    updateBadges();
    renderPIITab();

    // Sync recording state for the new tab
    const recRes = await chrome.runtime.sendMessage({ type: 'GET_RECORDING', tabId });
    state.recording = recRes?.recording !== false;
    updateRecordingUI();

    flashStatus('Tab switched');
  });

  // ── Clean up when a tab is closed ─────────────────────────────
  // Prevents stale cache entries and the "No tab with id: X" error when
  // the panel's own active tab is closed.
  chrome.tabs.onRemoved.addListener((removedTabId) => {
    // Always purge the cache entry
    state.tabCache.delete(removedTabId);

    // If the closed tab was our active tab, switch to the first available tab
    if (removedTabId === state.tabId) {
      state.tabId    = null;
      state.requests = [];
      state.filtered = [];
      state.selected = null;
      state.kbIndex  = -1;
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          // Trigger the onActivated path to fully re-init for the new tab
          chrome.tabs.onActivated.dispatch?.({ tabId: tabs[0].id });
        } else {
          // No active tab — just clear the UI
          renderTagList();
          updateStats();
          updateBadges();
        }
      });
    }
  });
  chrome.windows?.onFocusChanged?.addListener(async (windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) return;
    const tabs = await chrome.tabs.query({ active: true, windowId }).catch(() => []);
    const tab  = tabs[0];
    if (!tab || tab.id === state.tabId) return;
    chrome.tabs.onActivated.dispatch?.({ tabId: tab.id, windowId });
  });
}

// ── TAB NAVIGATION ─────────────────────────────────────────────
function initTabNav() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      switchTab(tab);
    });
  });
}

function switchTab(tab) {
  state.activeTab = tab;

  document.querySelectorAll('.tab-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.tab === tab)
  );
  document.querySelectorAll('.panel').forEach(p =>
    p.classList.toggle('active', p.id === `panel-${tab}`)
  );
}

// ── LIVE TAB INIT ──────────────────────────────────────────────
function initLiveTab() {
  // Record / Stop button
  document.getElementById('btnRecord').addEventListener('click', toggleRecording);

  // Clear button
  document.getElementById('btnClear').addEventListener('click', async () => {
    if (!state.tabId) return;
    await chrome.runtime.sendMessage({ type: 'CLEAR_LIVE_SESSION', tabId: state.tabId });
    state.clearGen++;
    state.tabCache.delete(state.tabId); // clear cached snapshot for this tab too
    state.requests  = [];
    state.filtered  = [];
    state.selected  = null;
    state.kbIndex   = -1;
    hideDetail();
    renderTagList();
    renderPIITab();
    updateStats();
    updateBadges();
    // Also clear the session-scoped ignore list
    if (state.ignoreList) state.ignoreList.clear();
    updateIgnoreBar();
    const badgePii = document.getElementById('badgePii');
    if (badgePii) badgePii.hidden = true;
  });

  // Save button
  document.getElementById('btnSave').addEventListener('click', () => openSaveModal());

  // Baseline button
  document.getElementById('btnBaseline').addEventListener('click', async () => {
    await openSaveModal(true);
  });

  // Filter buttons
  ['filterKnown', 'filterPII', 'filterWarn'].forEach(id => {
    document.getElementById(id).addEventListener('click', (e) => {
      const btn = e.currentTarget;
      const active = btn.dataset.active === 'true';
      btn.dataset.active = active ? 'false' : 'true';

      if (id === 'filterKnown') state.filters.known = !active;
      if (id === 'filterPII')   state.filters.pii   = !active;
      if (id === 'filterWarn')  state.filters.warn  = !active;

      applyFilters();
    });
  });

  // Search input — supports plain text and /regex/ mode
  const searchInput = document.getElementById('searchInput');
  const searchMode  = document.getElementById('searchMode');

  function compileSearch(raw) {
    const val = raw.trim();
    state.filters.text      = val;
    state.filters.textRegex = null;
    searchInput.classList.remove('search-regex', 'search-invalid');

    if (!val) return;

    // Auto-detect regex if value starts with /
    const rxMatch = val.match(/^\/(.+)\/([gimsuy]*)$/);
    if (rxMatch || searchMode.classList.contains('active')) {
      try {
        const pattern = rxMatch ? rxMatch[1] : val;
        const flags   = rxMatch ? rxMatch[2] : 'i';
        state.filters.textRegex = new RegExp(pattern, flags || 'i');
        searchInput.classList.add('search-regex');
      } catch {
        searchInput.classList.add('search-invalid');
        state.filters.textRegex = null;
      }
    }
    applyFilters();
  }

  searchInput.addEventListener('input', (e) => compileSearch(e.target.value));

  searchMode.addEventListener('click', () => {
    searchMode.classList.toggle('active');
    compileSearch(searchInput.value);
  });

  // Detail panel sub-tabs
  document.querySelectorAll('.dtab').forEach(btn => {
    btn.addEventListener('click', () => {
      state.activeDTab = btn.dataset.dtab;
      document.querySelectorAll('.dtab').forEach(b => b.classList.toggle('active', b === btn));
      if (state.selected) renderDetailBody(state.selected);
    });
  });

  // Detail close
  document.getElementById('dClose').addEventListener('click', hideDetail);

  // Check current recording state
  if (state.tabId) {
    chrome.runtime.sendMessage({ type: 'GET_RECORDING', tabId: state.tabId }, (res) => {
      state.recording = res?.recording !== false;
      updateRecordingUI();
    });
  }
}

// ── LOAD EXISTING LIVE SESSION ─────────────────────────────────
// (in case panel was closed and reopened mid-session)
async function loadLiveSession() {
  if (!state.tabId) return;
  const res = await chrome.runtime.sendMessage({ type: 'GET_LIVE_SESSION', tabId: state.tabId });
  if (res?.session?.requests?.length) {
    state.requests = res.session.requests;
    applyFilters();
    updateStats();
    updateBadges();
    // scroll to bottom
    const wrap = document.querySelector('.tag-list-wrap');
    if (wrap) wrap.scrollTop = wrap.scrollHeight;
  }
}

// ── REAL-TIME LISTENER ─────────────────────────────────────────
function listenForNewRequests() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== 'NEW_REQUEST') return;
    if (msg.tabId !== state.tabId)  return;

    state.requests.push(msg.entry);

    // Only add row if passes current filters
    if (entryPassesFilter(msg.entry)) {
      state.filtered.push(msg.entry);
      addTagRow(msg.entry);
      hideEmpty();
    }

    updateStats();
    updateBadges();

    // Update PII tab badge — only count findings from enabled patterns
    updatePIIBadge();
  });
}

// ── RECORDING STATE ────────────────────────────────────────────
async function toggleRecording() {
  state.recording = !state.recording;
  if (state.tabId) {
    await chrome.runtime.sendMessage({
      type: 'SET_RECORDING', tabId: state.tabId, value: state.recording
    });
  }
  updateRecordingUI();
}

function updateRecordingUI() {
  const btn = document.getElementById('btnRecord');
  const pip = document.getElementById('statusPip');
  const lbl = document.getElementById('statusLabel');

  if (state.recording) {
    btn.textContent = '⏹ Stop';
    btn.className   = 'btn btn-danger';
    pip.className   = 'status-pip recording';
    lbl.textContent = 'Recording';
  } else {
    btn.textContent = '▶ Record';
    btn.className   = 'btn btn-primary';
    pip.className   = 'status-pip idle';
    lbl.textContent = 'Idle';
  }
}

// ── FILTER LOGIC ───────────────────────────────────────────────
function applyFilters() {
  state.filtered = state.requests.filter(entryPassesFilter);
  renderTagList();
}

function entryPassesFilter(entry) {
  const { text, textRegex, known, pii, warn } = state.filters;

  // Ignore list — session-scoped hide rules set via right-click
  if (!entryPassesIgnore(entry)) return false;

  // "Known vendors only" — hides anything not in the user's Allow List.
  // An entry passes if it has a vendor AND that vendor is enabled (not explicitly
  // set to false in the whitelist).  Unknown/unidentified requests are always hidden.
  if (known) {
    if (!entry.isKnown) return false;
    if (state.whitelist[entry.vendor?.id] === false) return false;
  }

  if (pii  && !getVisiblePIIFindings(entry).length) return false;
  if (warn && !isWarn(entry))                        return false;

  if (text) {
    // Build a deep flat string covering every field and nested param value
    const parts = [
      entry.vendor?.name,
      entry.vendor?.category,
      entry.hostname,
      entry.eventName,
      entry.url,
      entry.method,
      String(entry.statusCode || ''),
      ...flattenDeep(entry.params    || {}),
      ...flattenDeep(entry.bodyParams|| {}),
    ].filter(Boolean);

    const haystack = parts.join(' ');

    if (textRegex) {
      if (!textRegex.test(haystack)) return false;
    } else {
      if (!haystack.toLowerCase().includes(text.toLowerCase())) return false;
    }
  }

  return true;
}

// Recursively flatten an object into an array of key + value strings
function flattenDeep(obj, depth = 0) {
  if (depth > 6) return [];
  if (obj === null || obj === undefined) return [];
  if (typeof obj !== 'object') return [String(obj)];
  const parts = [];
  for (const [k, v] of Object.entries(obj)) {
    parts.push(String(k));
    if (v && typeof v === 'object') {
      parts.push(...flattenDeep(v, depth + 1));
    } else {
      parts.push(String(v ?? ''));
    }
  }
  return parts;
}

function isWarn(entry) {
  return entry.isKnown && !entry.isWhitelisted;
}

// Returns only the PII findings that match currently ENABLED patterns.
// [] = PII detection fully OFF (return nothing).
// null = legacy "all on" (return everything).
// [ids] = only findings whose patternId is in the list.
function getVisiblePIIFindings(entry) {
  const findings = entry.piiFindings || [];
  if (!findings.length) return [];
  const enabled = state.settings?.piiPatterns;
  // null = all patterns on (legacy/unset)
  if (enabled === null || enabled === undefined) return findings;
  // [] = PII detection explicitly disabled
  if (Array.isArray(enabled) && enabled.length === 0) return [];
  return findings.filter(f => enabled.includes(f.patternId));
}

function getStatus(entry) {
  if (getVisiblePIIFindings(entry).length) return 'pii';
  if (isWarn(entry))                       return 'warn';
  return 'ok';
}

// ── TAG LIST RENDERING ─────────────────────────────────────────
function renderTagList() {
  const list = document.getElementById('tagList');
  // Remove all existing rows (keep empty state)
  list.querySelectorAll('.tag-row').forEach(r => r.remove());

  if (!state.filtered.length) {
    document.getElementById('emptyLive').hidden = false;
    return;
  }
  document.getElementById('emptyLive').hidden = true;
  state.filtered.forEach(entry => addTagRow(entry));
}

function addTagRow(entry) {
  const list  = document.getElementById('tagList');
  const empty = document.getElementById('emptyLive');
  if (empty) empty.hidden = true;

  const status    = getStatus(entry);
  const searchTerm = state.filters.text;   // used for highlight

  const row = document.createElement('div');
  row.className  = `tag-row status-${status}`;
  row.dataset.id = entry.id;

  // Vendor icon
  const icon = document.createElement('div');
  if (entry.vendor) {
    icon.className = 'v-icon';
    icon.style.background = entry.vendor.iconBg   || '#1c1b28';
    icon.style.color      = entry.vendor.iconColor || '#aaa';
    icon.textContent      = entry.vendor.icon || '?';
  } else {
    icon.className   = 'v-icon unknown';
    icon.textContent = '?';
  }

  // Info column
  const info = document.createElement('div');
  info.className = 'tag-info';

  const nameText = entry.vendor
    ? `${entry.vendor.name}${entry.eventName ? ' — ' + entry.eventName : ''}`
    : entry.hostname;

  const name = document.createElement('div');
  name.className = 'tag-name';
  highlightText(name, nameText, searchTerm);

  const host = document.createElement('div');
  host.className = 'tag-host';
  highlightText(host, entry.hostname, searchTerm);

  const chips = document.createElement('div');
  chips.className = 'tag-chips';

  if (entry.vendor?.category) chips.appendChild(mkChip(entry.vendor.category, 'blue'));

  // Status code chip — use teal for 3xx redirects to distinguish them visually
  if (entry.statusCode) {
    const code    = entry.statusCode;
    const isRedir = code >= 300 && code < 400;
    const color   = isRedir ? 'teal' : (code < 400 ? 'green' : 'red');
    chips.appendChild(mkChip(String(code), color));
  }

  // Redirect badge
  if (entry.isRedirect) {
    const rc = mkChip('↪ Redirect', 'teal');
    rc.title = 'This request was a redirect (3xx). The final destination may be a separate entry.';
    chips.appendChild(rc);
  }

  // PII chip — only if patterns are enabled and findings exist
  const visiblePII = getVisiblePIIFindings(entry);
  if (visiblePII.length) {
    const piiChip  = mkChip('PII', 'red');
    piiChip.title  = `${visiblePII.length} PII finding${visiblePII.length > 1 ? 's' : ''} — click to view in PII tab`;
    piiChip.style.cursor = 'pointer';
    piiChip.addEventListener('click', (e) => {
      e.stopPropagation();
      state.piiFilter.vendor   = entry.vendor?.name || entry.hostname || null;
      state.piiFilter.search   = '';
      state.piiFilter.severity = null;
      switchTab('pii');
      renderPIITab();
      const pb = document.querySelector('#panel-pii .panel-body');
      if (pb) pb.scrollTop = 0;
    });
    chips.appendChild(piiChip);
  }

  // "Unlisted" = this vendor is known to TagSentry but disabled in your Allow List.
  // This is distinct from "Unknown" = vendor not in the library at all.
  if (isWarn(entry)) {
    const warnChip = mkChip('Unlisted', 'amber');
    warnChip.title = 'This vendor is recognised but not enabled in your Allow List. '
      + 'Go to the Allow List tab to enable it, or turn on "Known vendors only" to hide unlisted requests.';
    chips.appendChild(warnChip);
  }
  if (!entry.isKnown) {
    const unkChip = mkChip('Unknown', 'grey');
    unkChip.title = 'This URL did not match any vendor in the TagSentry library or your custom vendor list.';
    chips.appendChild(unkChip);
  }

  info.appendChild(name);
  info.appendChild(host);
  info.appendChild(chips);

  // Time column
  const timeCol = document.createElement('div');
  timeCol.className = 'tag-time-col';

  const timeEl = document.createElement('div');
  timeEl.className = 'tag-time';
  timeEl.textContent = fmtTime(entry.timestamp);

  const dot = document.createElement('div');
  dot.className = `status-dot dot-${status === 'ok' ? 'green' : status === 'warn' ? 'amber' : 'red'}`;

  timeCol.appendChild(timeEl);
  timeCol.appendChild(dot);

  row.appendChild(icon);
  row.appendChild(info);
  row.appendChild(timeCol);

  row.addEventListener('click', () => selectEntry(entry));

  // ── Right-click context menu for ignore/exclusion ─────────────
  row.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    showIgnoreMenu(e, entry);
  });

  list.appendChild(row);

  // Auto-scroll to new row if near bottom
  const wrap = document.querySelector('.tag-list-wrap');
  if (wrap) {
    const nearBottom = wrap.scrollHeight - wrap.scrollTop - wrap.clientHeight < 80;
    if (nearBottom) wrap.scrollTop = wrap.scrollHeight;
  }
}

// ── Search term highlight ──────────────────────────────────────
// Sets container's content to text with any occurrences of `term`
// wrapped in <mark> elements.  Falls back to plain textContent when
// there is no active search term.
function highlightText(container, text, term) {
  if (!term || !text) {
    container.textContent = text || '';
    return;
  }
  container.textContent = '';
  try {
    // If regex mode is active use the compiled regex, otherwise plain string search
    const re = state.filters.textRegex
      ? new RegExp(`(${state.filters.textRegex.source})`, state.filters.textRegex.flags.replace('g','') + 'g')
      : new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');

    let last = 0;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (m.index > last) container.appendChild(document.createTextNode(text.slice(last, m.index)));
      const mark = document.createElement('mark');
      mark.className   = 'search-highlight';
      mark.textContent = m[0];
      container.appendChild(mark);
      last = re.lastIndex;
    }
    if (last < text.length) container.appendChild(document.createTextNode(text.slice(last)));
  } catch (_) {
    container.textContent = text;
  }
}

function mkChip(text, color) {
  const el = document.createElement('span');
  el.className = `chip chip-${color}`;
  el.textContent = text;
  return el;
}

function hideEmpty() {
  const e = document.getElementById('emptyLive');
  if (e) e.hidden = true;
}

// ── IGNORE LIST ────────────────────────────────────────────────
// The ignore list is a transient in-session set of hostnames / vendor ids
// that the user has chosen to hide from the Live feed via right-click.
// It is NOT persisted to storage (use the Exclusions on the Allow List tab
// for permanent exclusions).  It is cleared with the Clear button.
//
// state.ignoreList — Set of strings, each either:
//   "vendor:<id>"   — hides all entries from that vendor
//   "host:<host>"   — hides all entries from that hostname

if (!state.ignoreList) state.ignoreList = new Set();

function entryPassesIgnore(entry) {
  if (!state.ignoreList.size) return true;
  if (entry.vendor && state.ignoreList.has(`vendor:${entry.vendor.id}`)) return false;
  if (state.ignoreList.has(`host:${entry.hostname}`)) return false;
  return true;
}

// Patch entryPassesFilter to also check the ignore list
const _origPassesFilter = entryPassesFilter;
// NOTE: entryPassesFilter is re-declared below to include ignore check inline.
// The ignore check is injected into the function body directly to avoid
// double-declaring; see entryPassesFilter definition above which now calls
// entryPassesIgnore at the top.

function showIgnoreMenu(mouseEvent, entry) {
  // Remove any existing context menu
  document.getElementById('ignoreContextMenu')?.remove();

  const menu = document.createElement('div');
  menu.id          = 'ignoreContextMenu';
  menu.className   = 'context-menu';
  menu.style.cssText = `position:fixed;z-index:9999;top:${mouseEvent.clientY}px;left:${mouseEvent.clientX}px;`;

  const items = [];

  if (entry.vendor) {
    items.push({
      label: `🚫 Ignore all "${entry.vendor.name}" requests`,
      action: () => {
        state.ignoreList.add(`vendor:${entry.vendor.id}`);
        applyFilters(); updateStats(); updateBadges(); updateIgnoreBar();
      },
    });
  }

  items.push({
    label: `🚫 Ignore all requests from ${entry.hostname}`,
    action: () => {
      state.ignoreList.add(`host:${entry.hostname}`);
      applyFilters(); updateStats(); updateBadges(); updateIgnoreBar();
    },
  });

  if (state.ignoreList.size) {
    items.push({ separator: true });
    items.push({
      label: `✓ Clear ignore list (${state.ignoreList.size} rule${state.ignoreList.size > 1 ? 's' : ''})`,
      action: () => {
        state.ignoreList.clear();
        applyFilters(); updateStats(); updateBadges(); updateIgnoreBar();
      },
    });
  }

  items.forEach(item => {
    if (item.separator) {
      const hr = document.createElement('div');
      hr.style.cssText = 'height:1px;background:var(--border);margin:3px 0;';
      menu.appendChild(hr);
      return;
    }
    const btn = document.createElement('button');
    btn.className   = 'context-menu-item';
    btn.textContent = item.label;
    btn.addEventListener('click', () => { item.action(); menu.remove(); });
    menu.appendChild(btn);
  });

  document.body.appendChild(menu);

  // Close on any outside click
  const close = (e) => { if (!menu.contains(e.target)) { menu.remove(); document.removeEventListener('click', close); } };
  setTimeout(() => document.addEventListener('click', close), 10);
}

function updateIgnoreBar() {
  let bar = document.getElementById('ignoreBar');
  if (!state.ignoreList.size) { if (bar) bar.hidden = true; return; }

  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'ignoreBar';
    bar.className = 'ignore-bar';
    // Insert just above the tag list
    const wrap = document.querySelector('.tag-list-wrap');
    if (wrap) wrap.parentNode.insertBefore(bar, wrap);
  }
  bar.hidden = false;

  const rules = [...state.ignoreList].map(r => {
    const [type, val] = r.split(':');
    return type === 'vendor' ? val : val;
  });
  bar.innerHTML = '';

  const label = document.createElement('span');
  label.textContent = `Ignoring: ${rules.join(', ')}`;
  label.style.cssText = 'font-size:10px;color:var(--text-muted);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
  bar.appendChild(label);

  const clearBtn = document.createElement('button');
  clearBtn.className   = 'btn btn-sm';
  clearBtn.textContent = 'Clear';
  clearBtn.style.cssText = 'font-size:9px;padding:1px 6px;';
  clearBtn.addEventListener('click', () => {
    state.ignoreList.clear();
    applyFilters(); updateStats(); updateBadges(); updateIgnoreBar();
  });
  bar.appendChild(clearBtn);
}

// ── STATS ──────────────────────────────────────────────────────
function updateStats() {
  const total = state.requests.length;
  const pii   = state.requests.filter(r => getVisiblePIIFindings(r).length > 0).length;
  const warn  = state.requests.filter(r => isWarn(r)).length;
  const ok    = Math.max(0, total - pii - warn);

  document.getElementById('sTotal').textContent = total;
  document.getElementById('sOk').textContent    = ok;
  document.getElementById('sWarn').textContent  = warn;
  document.getElementById('sPii').textContent   = pii;
}

function updateBadges() {
  const total   = state.requests.length;
  const badge   = document.getElementById('badgeLive');
  if (badge) {
    badge.textContent = total > 99 ? '99+' : String(total);
    badge.hidden      = total === 0;
  }
  updatePIIBadge();
}

function updatePIIBadge() {
  const piiCount = state.requests.reduce((n, r) => n + getVisiblePIIFindings(r).length, 0);
  const badgePii = document.getElementById('badgePii');
  if (badgePii) {
    badgePii.textContent = piiCount > 99 ? '99+' : String(piiCount);
    badgePii.hidden      = piiCount === 0;
  }
}

// ── DETAIL PANEL ───────────────────────────────────────────────
function selectEntry(entry) {
  // Deselect previous
  document.querySelectorAll('.tag-row.selected').forEach(r => r.classList.remove('selected'));

  // Select new
  const row = document.querySelector(`.tag-row[data-id="${entry.id}"]`);
  if (row) row.classList.add('selected');

  state.selected = entry;
  showDetail(entry);
}

function showDetail(entry) {
  const panel = document.getElementById('detailPanel');
  panel.hidden = false;

  // Icon
  const icon = document.getElementById('dIcon');
  if (entry.vendor) {
    icon.className   = 'v-icon';
    icon.style.background = entry.vendor.iconBg   || '#1c1b28';
    icon.style.color      = entry.vendor.iconColor || '#aaa';
    icon.textContent      = entry.vendor.icon || '?';
  } else {
    icon.className   = 'v-icon unknown';
    icon.style.background = '';
    icon.style.color      = '';
    icon.textContent      = '?';
  }

  // Title
  document.getElementById('dTitle').textContent = entry.vendor
    ? `${entry.vendor.name}${entry.eventName ? ' — ' + entry.eventName : ''}`
    : entry.hostname;

  renderDetailBody(entry);
}

function hideDetail() {
  document.getElementById('detailPanel').hidden = true;
  document.querySelectorAll('.tag-row.selected').forEach(r => r.classList.remove('selected'));
  state.selected = null;
}

function renderDetailBody(entry) {
  const body = document.getElementById('dBody');
  body.innerHTML = '';

  // ── All sections visible simultaneously ──
  const sections = [
    {
      id:    'sec-params',
      label: 'Query Params',
      count: Object.keys(entry.params || {}).length,
      render: (c) => renderParamTable(c, entry.params || {}, entry.piiFindings || []),
    },
    {
      id:    'sec-body',
      label: 'Body',
      count: Object.keys(entry.bodyParams || {}).length,
      render: (c) => renderBodySection(c, entry.bodyParams || {}, entry.piiFindings || []),
    },
    {
      id:    'sec-raw',
      label: 'Raw URL',
      count: null,
      render: (c) => renderRawUrl(c, entry.rawUrl || entry.url || ''),
    },
  ];

  sections.forEach(sec => {
    // Recall collapsed state per section id
    const wasCollapsed = state[sec.id + '_collapsed'];

    const section = document.createElement('div');
    section.className = 'detail-section' + (wasCollapsed ? ' collapsed' : '');
    section.id = sec.id;

    const hdr = document.createElement('div');
    hdr.className = 'detail-section-hdr';

    const title = document.createElement('span');
    title.className   = 'detail-section-title';
    title.textContent = sec.label;

    const count = document.createElement('span');
    count.className   = 'detail-section-count';
    count.textContent = sec.count !== null ? `${sec.count} param${sec.count !== 1 ? 's' : ''}` : '';

    const chevron = document.createElement('span');
    chevron.className   = 'detail-section-chevron';
    chevron.textContent = '▶';

    hdr.appendChild(title);
    hdr.appendChild(count);
    hdr.appendChild(chevron);
    hdr.addEventListener('click', () => {
      section.classList.toggle('collapsed');
      state[sec.id + '_collapsed'] = section.classList.contains('collapsed');
    });

    const secBody = document.createElement('div');
    secBody.className = 'detail-section-body';

    section.appendChild(hdr);
    section.appendChild(secBody);
    body.appendChild(section);

    // Render content into section body
    sec.render(secBody);
  });
}

function renderParamTable(container, params, piiFindings) {
  const keys = Object.keys(params);
  if (!keys.length) {
    const el = document.createElement('div');
    el.className = 'detail-empty';
    el.textContent = 'No parameters found.';
    container.appendChild(el);
    return;
  }

  const piiParams = new Set(piiFindings.map(f => f.param));

  keys.forEach(key => {
    const row  = document.createElement('div');
    row.className = 'param-row';

    const k = document.createElement('div');
    k.className   = 'p-key';
    k.textContent = key;

    const v = document.createElement('div');
    const isPII = piiParams.has(key);
    v.className   = isPII ? 'p-val pii-val' : 'p-val';
    v.textContent = String(params[key] ?? '');

    if (isPII) {
      const badge = document.createElement('span');
      badge.className   = 'pii-inline';
      badge.textContent = '⚠ PII';
      v.appendChild(badge);
    }

    row.appendChild(k);
    row.appendChild(v);
    container.appendChild(row);
  });
}

function renderRawUrl(container, url) {
  const wrap = document.createElement('div');
  wrap.className = 'raw-url-wrap';

  const pre = document.createElement('div');
  pre.className   = 'raw-url';
  pre.textContent = url;

  const btn = document.createElement('button');
  btn.className   = 'copy-btn';
  btn.textContent = '📋 Copy URL';
  btn.addEventListener('click', () => {
    navigator.clipboard.writeText(url).then(() => {
      btn.textContent = '✓ Copied!';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = '📋 Copy URL';
        btn.classList.remove('copied');
      }, 1500);
    });
  });

  wrap.appendChild(pre);
  wrap.appendChild(btn);
  container.appendChild(wrap);
}

// ── SAVE MODAL ─────────────────────────────────────────────────
let _saveAsBaseline = false;

function openSaveModal(forceBaseline = false) {
  _saveAsBaseline = forceBaseline;
  const modal = document.getElementById('modalSave');
  const input = document.getElementById('saveNameInput');
  const bl    = document.getElementById('saveAsBaseline');

  // Suggest a name
  try {
    const hostname = new URL(state.requests[0]?.url || '').hostname || 'session';
    input.value = `${hostname} — ${fmtDate(Date.now())}`;
  } catch {
    input.value = `Session — ${fmtDate(Date.now())}`;
  }

  if (bl) bl.checked = forceBaseline;
  modal.hidden = false;
  input.focus();
  input.select();
}

function initSaveModal() {
  document.getElementById('btnCancelSave').addEventListener('click', () => {
    document.getElementById('modalSave').hidden = true;
  });

  document.getElementById('btnConfirmSave').addEventListener('click', async () => {
    const name = document.getElementById('saveNameInput').value.trim()
      || `Session — ${fmtDate(Date.now())}`;
    const setBaseline = document.getElementById('saveAsBaseline').checked;

    if (!state.tabId) return;

    const res = await chrome.runtime.sendMessage({
      type: 'SAVE_SESSION',
      tabId: state.tabId,
      name,
      setBaseline,
    });

    document.getElementById('modalSave').hidden = true;

    if (res?.ok) {
      // Immediately refresh the Sessions list and navigate there so the user
      // can see (and use) the just-saved session without any extra steps.
      await loadSessions();
      populateDiffSelects();
      switchTab('sessions');
      flashStatus('Session saved ✓');
    } else {
      flashStatus(res?.error || 'Save failed', true);
    }
  });

  // Close on overlay click
  document.getElementById('modalSave').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) e.currentTarget.hidden = true;
  });
}

// ── HELPERS ────────────────────────────────────────────────────
function fmtTime(ts) {
  return new Date(ts).toLocaleTimeString('en-US', { hour12: false });
}

function fmtDate(ts) {
  return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function flashStatus(msg, isError = false) {
  const lbl = document.getElementById('statusLabel');
  const pip  = document.getElementById('statusPip');
  const prev = lbl.textContent;
  lbl.textContent = msg;
  lbl.style.color = isError ? 'var(--red)' : 'var(--green)';
  setTimeout(() => {
    lbl.textContent = prev;
    lbl.style.color = '';
  }, 2000);
}

// expose for later steps
window.__TS = { state, switchTab, applyFilters, updateStats, updateBadges, fmtDate, fmtTime };

// ══════════════════════════════════════════════════════════════
// STEP 4 — SESSIONS TAB
// ══════════════════════════════════════════════════════════════

async function initSessionsTab() {
  await loadSessions();

  // Search filter
  document.getElementById('sessSearch').addEventListener('input', (e) => {
    renderSessionList(e.target.value.trim().toLowerCase());
  });

  // New Recording button — switches to Live tab and starts recording
  document.getElementById('btnNewRec').addEventListener('click', () => {
    switchTab('live');
    if (!state.recording) toggleRecording();
  });

  // Delete selected button
  document.getElementById('btnDelSess').addEventListener('click', async () => {
    const checked = [...document.querySelectorAll('.sess-check:checked')];
    if (!checked.length) return;
    if (!confirm(`Delete ${checked.length} session(s)?`)) return;
    for (const cb of checked) {
      await chrome.runtime.sendMessage({ type: 'DELETE_SESSION', id: cb.dataset.id });
    }
    await loadSessions();
    populateDiffSelects();
  });
}

async function loadSessions() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_SESSIONS' });
    state.sessions   = res?.sessions   || [];
    state.baselineId = res?.baselineId || null;
  } catch (_) {
    state.sessions   = [];
    state.baselineId = null;
  }
  // Always update both the list view and the diff selects
  const searchEl = document.getElementById('sessSearch');
  renderSessionList(searchEl?.value?.trim().toLowerCase() || '');
  populateDiffSelects();
}

function renderSessionList(filter) {
  const container = document.getElementById('sessionList');
  container.innerHTML = '';

  const visible = filter
    ? state.sessions.filter(s =>
        s.name?.toLowerCase().includes(filter) ||
        s.pageUrl?.toLowerCase().includes(filter)
      )
    : state.sessions;

  if (!visible.length) {
    container.innerHTML = `
      <div class="empty">
        <div class="empty-icon">💾</div>
        <div class="empty-title">${filter ? 'No matches' : 'No sessions saved yet'}</div>
        <div class="empty-sub">${filter ? 'Try a different search term.' : 'Record tags on the Live tab, then click Save.'}</div>
      </div>`;
    return;
  }

  visible.forEach(sess => container.appendChild(buildSessionItem(sess)));
}

function buildSessionItem(sess) {
  const isBaseline = sess.id === state.baselineId;
  const item = document.createElement('div');
  item.className = `session-item${isBaseline ? ' is-baseline' : ''}`;

  // Checkbox
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.className = 'sess-check';
  cb.dataset.id = sess.id;
  cb.style.cssText = 'flex-shrink:0;margin-top:3px;accent-color:var(--accent);cursor:pointer';

  // Icon
  const icon = document.createElement('div');
  icon.className = 'sess-icon';
  icon.textContent = isBaseline ? '📌' : '📋';

  // Info
  const info = document.createElement('div');
  info.className = 'sess-info';

  const name = document.createElement('div');
  name.className = 'sess-name';
  name.textContent = sess.name || 'Untitled Session';

  const meta = document.createElement('div');
  meta.className = 'sess-meta';
  const hostname = (() => { try { return new URL(sess.pageUrl || '').hostname; } catch { return sess.pageUrl || '—'; }})();
  meta.textContent = `${hostname} · ${fmtDate(sess.savedAt)} · ${sess.requestCount || 0} tags`;

  const chips = document.createElement('div');
  chips.className = 'sess-chips';
  if (isBaseline)          chips.appendChild(mkSessionChip('BASELINE', 'blue'));
  if (sess.piiCount > 0)   chips.appendChild(mkSessionChip(`${sess.piiCount} PII`, 'red'));
  if (sess.requestCount)   chips.appendChild(mkSessionChip(`${sess.requestCount} tags`, 'grey'));
  if (!sess.piiCount)      chips.appendChild(mkSessionChip('Clean', 'green'));

  info.appendChild(name);
  info.appendChild(meta);
  info.appendChild(chips);

  // Actions
  const actions = document.createElement('div');
  actions.className = 'sess-actions';

  const btnLoad = document.createElement('button');
  btnLoad.className = 'btn btn-sm';
  btnLoad.textContent = 'Load';
  btnLoad.addEventListener('click', () => loadSessionIntoLive(sess));

  const btnCompare = document.createElement('button');
  btnCompare.className = 'btn btn-sm btn-accent';
  btnCompare.textContent = 'Diff ▾';
  btnCompare.addEventListener('click', (e) => {
    e.stopPropagation();
    openDiffFromSession(sess);
  });

  const btnBaseline = document.createElement('button');
  btnBaseline.className = 'btn btn-sm';
  btnBaseline.title = isBaseline ? 'Already baseline' : 'Set as baseline';
  btnBaseline.textContent = isBaseline ? '📌' : '⚡';
  btnBaseline.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'SET_BASELINE', id: sess.id });
    await loadSessions();
  });

  const btnDel = document.createElement('button');
  btnDel.className = 'btn btn-sm btn-danger';
  btnDel.textContent = '🗑';
  btnDel.title = 'Delete session';
  btnDel.addEventListener('click', async () => {
    if (!confirm(`Delete "${sess.name}"?`)) return;
    await chrome.runtime.sendMessage({ type: 'DELETE_SESSION', id: sess.id });
    await loadSessions();
    populateDiffSelects();
  });

  actions.appendChild(btnLoad);
  actions.appendChild(btnCompare);
  actions.appendChild(btnBaseline);
  actions.appendChild(btnDel);

  item.appendChild(cb);
  item.appendChild(icon);
  item.appendChild(info);
  item.appendChild(actions);
  return item;
}

function mkSessionChip(text, color) {
  const el = document.createElement('span');
  el.className = `chip chip-${color}`;
  el.textContent = text;
  return el;
}

// Load a saved session's requests back into the Live view for inspection
function loadSessionIntoLive(sess) {
  state.requests = sess.requests || [];
  state.selected = null;
  hideDetail();
  applyFilters();
  updateStats();
  updateBadges();
  switchTab('live');
  flashStatus(`Loaded: ${sess.name}`);
}

// Shortcut: jump to Diff tab pre-filling Session B with this session
function openDiffFromSession(sess) {
  switchTab('diff');
  // Pre-fill B selector; A defaults to baseline if set
  const selB = document.getElementById('diffSelB');
  if (selB) selB.value = sess.id;

  const selA = document.getElementById('diffSelA');
  if (selA && state.baselineId && selA.value === '') {
    selA.value = state.baselineId;
  }
}

// ══════════════════════════════════════════════════════════════
// STEP 4 — DIFF TAB
// ══════════════════════════════════════════════════════════════

function initDiffTab() {
  document.getElementById('btnRunDiff').addEventListener('click', runDiff);
}

function populateDiffSelects() {
  ['diffSelA', 'diffSelB'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const prev = sel.value;
    sel.innerHTML = '<option value="">— choose session —</option>';
    state.sessions.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = s.name || 'Untitled';
      if (s.id === state.baselineId) opt.textContent += ' 📌';
      sel.appendChild(opt);
    });
    // Restore previous selection if still valid
    if (prev && state.sessions.find(s => s.id === prev)) sel.value = prev;
    // Auto-select baseline in A slot
    if (id === 'diffSelA' && !sel.value && state.baselineId) sel.value = state.baselineId;
  });
}

async function runDiff() {
  const idA = document.getElementById('diffSelA').value;
  const idB = document.getElementById('diffSelB').value;

  if (!idA || !idB) {
    showDiffError('Please select two sessions to compare.'); return;
  }
  if (idA === idB) {
    showDiffError('Choose two different sessions.'); return;
  }

  const res = await chrome.runtime.sendMessage({ type: 'DIFF_SESSIONS', idA, idB });
  if (res?.error) { showDiffError(res.error); return; }
  renderDiff(res.diff);
}

function showDiffError(msg) {
  document.getElementById('diffResults').innerHTML =
    `<div class="empty"><div class="empty-icon">⚠️</div><div class="empty-title">${msg}</div></div>`;
}

function renderDiff(diff) {
  const container = document.getElementById('diffResults');
  container.innerHTML = '';

  const { sessionA, sessionB, changes, summary } = diff;

  // ── Session meta banner ──
  const banner = document.createElement('div');
  banner.style.cssText = 'display:grid;grid-template-columns:1fr auto 1fr;gap:8px;align-items:center;margin-bottom:10px;';

  const makeSessionMeta = (sess) => {
    const el = document.createElement('div');
    el.style.cssText = 'background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);padding:8px 10px;';
    el.innerHTML = `
      <div style="font-size:11px;font-weight:600;color:var(--text);margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(sess.name || 'Untitled')}</div>
      <div style="font-family:var(--mono);font-size:9px;color:var(--text4)">${esc(tryHostname(sess.url))} · ${sess.count} tags</div>`;
    return el;
  };

  const vs = document.createElement('div');
  vs.className = 'diff-vs';
  vs.textContent = 'vs';

  banner.appendChild(makeSessionMeta(sessionA));
  banner.appendChild(vs);
  banner.appendChild(makeSessionMeta(sessionB));
  container.appendChild(banner);

  // ── Summary chips + filter row ──
  if (!changes.length) {
    const noChange = document.createElement('div');
    noChange.className = 'empty';
    noChange.innerHTML = `<div class="empty-icon">✅</div><div class="empty-title">Sessions are identical</div><div class="empty-sub">No tag differences found between these two sessions.</div>`;
    container.appendChild(noChange);
    return;
  }

  // Filter state
  let activeFilter = 'all';

  const filterRow = document.createElement('div');
  filterRow.className = 'diff-summary';
  filterRow.style.cssText = 'display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px;align-items:center;';

  const filterDefs = [
    { key: 'all',     label: `All (${changes.length})`,              cls: '' },
    { key: 'removed', label: `− Removed (${summary.removed})`,       cls: 'active-r' },
    { key: 'added',   label: `+ Added (${summary.added})`,           cls: 'active-g' },
    { key: 'changed', label: `~ Changed (${summary.changed})`,       cls: 'active-a' },
  ];

  const filterBtns = {};
  filterDefs.forEach(def => {
    const btn = document.createElement('button');
    btn.className = `diff-filter-btn${def.key === 'all' ? ' ' + 'active-a'.replace('active-a','') : ''}`;
    btn.textContent = def.label;
    btn.style.cssText = def.key === 'all' ? 'background:var(--accent-lt);border-color:var(--accent-bd);color:var(--accent)' : '';
    btn.addEventListener('click', () => {
      activeFilter = def.key;
      // Reset all button styles
      filterDefs.forEach(d => {
        filterBtns[d.key].style.cssText = '';
        filterBtns[d.key].className = 'diff-filter-btn';
      });
      // Activate clicked
      btn.className = `diff-filter-btn ${def.cls}`;
      if (def.key === 'all') btn.style.cssText = 'background:var(--accent-lt);border-color:var(--accent-bd);color:var(--accent)';
      renderDiffRows(changeList, activeFilter);
    });
    filterBtns[def.key] = btn;
    filterRow.appendChild(btn);
  });

  // Export diff button
  const exportBtn = document.createElement('button');
  exportBtn.className = 'btn btn-sm btn-accent';
  exportBtn.style.marginLeft = 'auto';
  exportBtn.textContent = '📤 Export';
  exportBtn.addEventListener('click', () => exportDiff(diff));
  filterRow.appendChild(exportBtn);

  container.appendChild(filterRow);

  // ── Change rows ──
  const changeList = document.createElement('div');
  changeList.id = 'diffChangeList';
  container.appendChild(changeList);
  renderDiffRows(changeList, 'all');

  function renderDiffRows(el, filter) {
    el.innerHTML = '';
    const visible = filter === 'all' ? changes : changes.filter(c => c.type === filter);

    if (!visible.length) {
      el.innerHTML = `<div class="detail-empty">No ${filter} changes.</div>`;
      return;
    }

    visible.forEach(change => el.appendChild(buildDiffRow(change)));
  }
}

function buildDiffRow(change) {
  const row = document.createElement('div');
  row.className = `diff-row dr-${change.type}`;

  const markerMap = { removed: '−', added: '+', changed: '~' };
  const markerClass = { removed: 'm-minus', added: 'm-plus', changed: 'm-tilde' };

  const marker = document.createElement('div');
  marker.className = `dr-marker ${markerClass[change.type]}`;
  marker.textContent = markerMap[change.type];

  const content = document.createElement('div');
  content.className = 'dr-content';

  const vendorLine = document.createElement('strong');
  vendorLine.textContent = change.vendorName || change.key;
  content.appendChild(vendorLine);

  if (change.category) {
    const cat = document.createElement('span');
    cat.style.cssText = 'font-size:9px;color:var(--text4);margin-left:6px;';
    cat.textContent = change.category;
    content.appendChild(cat);
  }

  if (change.type === 'removed') {
    const sub = document.createElement('small');
    sub.textContent = change.hostname || '';
    content.appendChild(document.createElement('br'));
    content.appendChild(sub);
  }

  if (change.type === 'added') {
    const sub = document.createElement('small');
    sub.textContent = `${change.hostname || ''}${!change.isWhitelisted ? ' · not in allow list' : ''}`;
    content.appendChild(document.createElement('br'));
    content.appendChild(sub);
  }

  if (change.type === 'changed' && change.paramDiff?.length) {
    const maxShow = 4;
    change.paramDiff.slice(0, maxShow).forEach(pd => {
      const line = document.createElement('div');
      line.style.cssText = 'margin-top:3px;font-size:9px;';

      const keyEl = document.createElement('span');
      keyEl.style.color = 'var(--text3)';
      keyEl.textContent = `${pd.key}: `;

      if (pd.type === 'changed') {
        const oldEl = document.createElement('span');
        oldEl.className = 'v-old';
        oldEl.textContent = truncate(String(pd.old ?? ''), 40);
        const newEl = document.createElement('span');
        newEl.className = 'v-new';
        newEl.textContent = truncate(String(pd.nw ?? ''), 40);
        line.appendChild(keyEl);
        line.appendChild(oldEl);
        line.appendChild(newEl);
      } else if (pd.type === 'added') {
        const newEl = document.createElement('span');
        newEl.className = 'v-new';
        newEl.textContent = `+ ${truncate(String(pd.nw ?? ''), 40)}`;
        line.appendChild(keyEl);
        line.appendChild(newEl);
      } else {
        const oldEl = document.createElement('span');
        oldEl.className = 'v-old';
        oldEl.textContent = `− ${truncate(String(pd.old ?? ''), 40)}`;
        line.appendChild(keyEl);
        line.appendChild(oldEl);
      }

      content.appendChild(line);
    });

    if (change.paramDiff.length > maxShow) {
      const more = document.createElement('div');
      more.style.cssText = 'font-size:9px;color:var(--text4);margin-top:2px;';
      more.textContent = `+${change.paramDiff.length - maxShow} more param changes`;
      content.appendChild(more);
    }
  }

  // Badge
  const badgeMap = {
    removed: { text: 'Missing', cls: 'chip-red' },
    added:   { text: change.isKnown ? 'New' : 'Unknown', cls: 'chip-amber' },
    changed: { text: 'Changed', cls: 'chip-amber' },
  };
  const badge = document.createElement('span');
  const bDef = badgeMap[change.type];
  badge.className = `chip ${bDef.cls} dr-badge`;
  badge.textContent = bDef.text;

  row.appendChild(marker);
  row.appendChild(content);
  row.appendChild(badge);
  return row;
}

function exportDiff(diff) {
  const lines = [
    `TagSentry Diff Report`,
    `Session A: ${diff.sessionA.name} (${diff.sessionA.count} tags)`,
    `Session B: ${diff.sessionB.name} (${diff.sessionB.count} tags)`,
    `Generated: ${new Date().toISOString()}`,
    '',
    `Summary: ${diff.summary.removed} removed, ${diff.summary.added} added, ${diff.summary.changed} changed`,
    '',
  ];

  diff.changes.forEach(c => {
    const prefix = c.type === 'removed' ? '−' : c.type === 'added' ? '+' : '~';
    lines.push(`${prefix} [${c.type.toUpperCase()}] ${c.vendorName || c.key} (${c.category || ''})`);
    if (c.hostname) lines.push(`  URL: ${c.hostname}`);
    if (c.paramDiff) {
      c.paramDiff.forEach(pd => {
        if (pd.type === 'changed') lines.push(`  ~ ${pd.key}: "${pd.old}" → "${pd.nw}"`);
        if (pd.type === 'added')   lines.push(`  + ${pd.key}: "${pd.nw}"`);
        if (pd.type === 'removed') lines.push(`  − ${pd.key}: "${pd.old}"`);
      });
    }
    lines.push('');
  });

  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `tagsentry-diff-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Shared helpers (Sessions + Diff) ──────────────────────────
function esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function tryHostname(url) {
  try { return new URL(url).hostname; } catch { return url || '—'; }
}

function truncate(str, max) {
  return str.length > max ? str.slice(0, max) + '…' : str;
}



// ══════════════════════════════════════════════════════════════
// STEP 5 — PII TAB
// ══════════════════════════════════════════════════════════════

function initPIITab() {
  document.getElementById('btnExportPII').addEventListener('click', exportPIIReport);
  document.querySelector('[data-tab="pii"]').addEventListener('click', renderPIITab);

  // PII search
  const piiSearch = document.getElementById('piiSearch');
  if (piiSearch) {
    piiSearch.addEventListener('input', (e) => {
      state.piiFilter.search = e.target.value.trim().toLowerCase();
      renderPIITab();
    });
  }

  // Severity filter buttons
  ['High','Medium','Low'].forEach(sev => {
    const btn = document.getElementById('piiFilter' + sev);
    if (!btn) return;
    btn.addEventListener('click', () => {
      const sevUpper = sev.toUpperCase();
      const isActive = state.piiFilter.severity === sevUpper;
      state.piiFilter.severity = isActive ? null : sevUpper;
      ['High','Medium','Low'].forEach(s => {
        const b = document.getElementById('piiFilter' + s);
        if (b) b.dataset.active = (state.piiFilter.severity === s.toUpperCase()) ? 'true' : 'false';
      });
      renderPIITab();
    });
  });
}

function renderPIITab() {
  const allFindings = gatherPIIFindings();
  const container   = document.getElementById('piiContent');
  const exportBtn   = document.getElementById('btnExportPII');
  container.innerHTML = '';

  // Vendor filter banner (set by clicking PII chip on a tag row)
  if (state.piiFilter.vendor) {
    const banner = document.createElement('div');
    banner.className = 'pii-vendor-banner';
    const label = document.createElement('span');
    label.innerHTML = `Showing: <strong>${esc(state.piiFilter.vendor)}</strong>`;
    const clearBtn = document.createElement('button');
    clearBtn.className = 'pii-vendor-clear';
    clearBtn.textContent = '✕ Clear filter';
    clearBtn.addEventListener('click', () => {
      state.piiFilter.vendor = null;
      const piiSearch = document.getElementById('piiSearch');
      if (piiSearch) piiSearch.value = '';
      state.piiFilter.search = '';
      renderPIITab();
    });
    banner.appendChild(label);
    banner.appendChild(clearBtn);
    container.appendChild(banner);
  }

  // Apply filters
  let findings = allFindings;
  if (state.piiFilter.vendor)   findings = findings.filter(f => f.tagName === state.piiFilter.vendor);
  if (state.piiFilter.severity) findings = findings.filter(f => f.severity === state.piiFilter.severity);
  if (state.piiFilter.search) {
    const q = state.piiFilter.search;
    findings = findings.filter(f =>
      (f.param       || '').toLowerCase().includes(q) ||
      (f.patternName || '').toLowerCase().includes(q) ||
      (f.tagName     || '').toLowerCase().includes(q) ||
      (f.severity    || '').toLowerCase().includes(q)
    );
  }

  if (!findings.length) {
    exportBtn.hidden = !allFindings.length;
    const empty = document.createElement('div');
    empty.className = 'empty';
    if (allFindings.length) {
      empty.innerHTML = '<div class="empty-icon">🔍</div><div class="empty-title">No matches</div><div class="empty-sub">Try adjusting your search or filters.</div>';
    } else {
      empty.innerHTML = '<div class="empty-icon">🔒</div><div class="empty-title">No PII detected</div><div class="empty-sub">PII findings from the current live session appear here as tags are recorded.</div>';
    }
    container.appendChild(empty);
    return;
  }

  exportBtn.hidden = false;

  const totalLabel = allFindings.length !== findings.length
    ? `${findings.length} of ${allFindings.length} findings`
    : `${findings.length} Finding${findings.length !== 1 ? 's' : ''}`;

  const alertEl = document.createElement('div');
  alertEl.className = 'pii-alert';
  alertEl.innerHTML = `
    <div class="pii-alert-title">⚠ ${totalLabel} Detected</div>
    <div class="pii-alert-body">Personal data found in outbound tag payloads. Review each finding and confirm legal basis and consent before production use.</div>`;
  container.appendChild(alertEl);

  // Group by severity
  const groups = { HIGH: [], MEDIUM: [], LOW: [] };
  findings.forEach(f => { (groups[f.severity] || groups.LOW).push(f); });

  ['HIGH', 'MEDIUM', 'LOW'].forEach(sev => {
    if (!groups[sev].length) return;
    const label = document.createElement('div');
    label.className = 'pii-sev-label';
    label.textContent = `${sev} Severity (${groups[sev].length})`;
    container.appendChild(label);
    groups[sev].forEach(f => container.appendChild(buildPIIRow(f)));
  });
}

function buildPIIRow(f) {
  const row = document.createElement('div');
  row.className = 'pii-row';

  const sev = document.createElement('div');
  sev.className = `sev-badge sev-${f.severity}`;
  sev.textContent = f.severity;

  const detail = document.createElement('div');
  detail.className = 'pii-detail';

  const param = document.createElement('div');
  param.className = 'pii-param';
  param.textContent = `${f.param} → ${truncate(f.value, 60)}`;

  const pattern = document.createElement('div');
  pattern.className = 'pii-pattern';
  pattern.textContent = `Pattern: ${f.patternName}`;

  const source = document.createElement('div');
  source.className = 'pii-source';
  source.textContent = `Tag: ${f.tagName || '—'} · ${fmtTime(f.timestamp)}`;

  detail.appendChild(param);
  detail.appendChild(pattern);
  detail.appendChild(source);
  row.appendChild(sev);
  row.appendChild(detail);
  return row;
}

function gatherPIIFindings() {
  // Only return findings from currently enabled patterns
  const seen = new Set();
  const out  = [];
  state.requests.forEach(req => {
    getVisiblePIIFindings(req).forEach(f => {
      const key = `${f.param}:${f.value}:${req.id}`;
      if (seen.has(key)) return;
      seen.add(key);
      out.push({
        ...f,
        tagName:   req.vendor?.name || req.hostname,
        timestamp: req.timestamp,
        requestId: req.id,
      });
    });
  });
  return out;
}

function exportPIIReport() {
  const findings = gatherPIIFindings();
  const report = {
    generated:   new Date().toISOString(),
    sessionUrl:  state.requests[0] ? tryHostname(state.requests[0].url) : '—',
    totalTags:   state.requests.length,
    piiFindings: findings.length,
    findings:    findings.map(f => ({
      severity:    f.severity,
      parameter:   f.param,
      value:       '[REDACTED]',
      patternType: f.patternName,
      tag:         f.tagName,
      timestamp:   new Date(f.timestamp).toISOString(),
    })),
  };

  const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `tagsentry-pii-report-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ══════════════════════════════════════════════════════════════
// STEP 5 — ALLOW LIST TAB
// ══════════════════════════════════════════════════════════════

// Full built-in vendor list (mirrors vendors.js categories)
const BUILTIN_VENDOR_IDS = [
  { id:'ga4',        name:'Google Analytics 4',            category:'Analytics' },
  { id:'ua',         name:'Universal Analytics',           category:'Analytics' },
  { id:'adobe_aa',   name:'Adobe Analytics',               category:'Analytics' },
  { id:'mixpanel',   name:'Mixpanel',                      category:'Analytics' },
  { id:'amplitude',  name:'Amplitude',                     category:'Analytics' },
  { id:'segment',    name:'Segment',                       category:'Analytics' },
  { id:'heap',       name:'Heap',                          category:'Analytics' },
  { id:'matomo',     name:'Matomo / Piwik',                category:'Analytics' },
  { id:'fullstory',  name:'FullStory',                     category:'Analytics' },
  { id:'rudderstack',name:'RudderStack',                   category:'Analytics' },
  { id:'posthog',    name:'PostHog',                       category:'Analytics' },
  { id:'pendo',      name:'Pendo',                         category:'Analytics' },
  { id:'meta_pixel', name:'Meta Pixel',                    category:'Advertising' },
  { id:'tiktok',     name:'TikTok Pixel',                  category:'Advertising' },
  { id:'google_ads', name:'Google Ads',                    category:'Advertising' },
  { id:'dv360',      name:'Display & Video 360',           category:'Advertising' },
  { id:'linkedin',   name:'LinkedIn Insight Tag',          category:'Advertising' },
  { id:'twitter_x',  name:'X (Twitter) Pixel',             category:'Advertising' },
  { id:'pinterest',  name:'Pinterest Tag',                 category:'Advertising' },
  { id:'snapchat',   name:'Snapchat Pixel',                category:'Advertising' },
  { id:'bing_uet',   name:'Microsoft / Bing UET',          category:'Advertising' },
  { id:'criteo',     name:'Criteo',                        category:'Advertising' },
  { id:'taboola',    name:'Taboola',                       category:'Advertising' },
  { id:'outbrain',   name:'Outbrain',                      category:'Advertising' },
  { id:'reddit_ads', name:'Reddit Pixel',                  category:'Advertising' },
  { id:'gtm',        name:'Google Tag Manager',            category:'Tag Mgmt' },
  { id:'tealium_iq', name:'Tealium iQ',                    category:'Tag Mgmt' },
  { id:'adobe_dtm',  name:'Adobe Experience Platform Tags',category:'Tag Mgmt' },
  { id:'ensighten',  name:'Ensighten',                     category:'Tag Mgmt' },
  { id:'onetrust',   name:'OneTrust CMP',                  category:'Consent' },
  { id:'cookiebot',  name:'Cookiebot',                     category:'Consent' },
  { id:'trustarc',   name:'TrustArc',                      category:'Consent' },
  { id:'usercentrics',name:'Usercentrics',                 category:'Consent' },
  { id:'didomi',     name:'Didomi',                        category:'Consent' },
  { id:'optimizely', name:'Optimizely',                    category:'A/B Testing' },
  { id:'vwo',        name:'VWO',                           category:'A/B Testing' },
  { id:'abtasty',    name:'AB Tasty',                      category:'A/B Testing' },
  { id:'hotjar',     name:'Hotjar',                        category:'Heatmaps' },
  { id:'clarity',    name:'Microsoft Clarity',             category:'Heatmaps' },
  { id:'mouseflow',  name:'Mouseflow',                     category:'Heatmaps' },
  { id:'lucky_orange',name:'Lucky Orange',                 category:'Heatmaps' },
  { id:'tealium_as', name:'Tealium AudienceStream',        category:'CDP' },
  { id:'klaviyo',    name:'Klaviyo',                       category:'CDP' },
  { id:'braze',      name:'Braze',                         category:'CDP' },
  { id:'lytics',     name:'Lytics',                        category:'CDP' },
];

async function initAllowListTab() {
  const res = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
  state.whitelist      = res?.whitelist      || {};
  state.customVendors  = res?.customVendors  || [];
  state.exclusions     = res?.exclusions     || {};
  state.vendorOverrides= res?.vendorOverrides|| {};

  renderAllowList('');

  // Search
  document.getElementById('wlSearch').addEventListener('input', e => {
    renderAllowList(e.target.value.trim().toLowerCase());
  });

  // Enable / Disable All
  document.getElementById('btnWLToggleAll').addEventListener('click', async () => {
    const allVendors = [
      ...BUILTIN_VENDOR_IDS,
      ...state.customVendors.map(v => ({ ...v, isCustom: true })),
    ];
    const anyDisabled = allVendors.some(v => state.whitelist[v.id] === false);
    // If anything is disabled → enable all. If all enabled → disable all.
    allVendors.forEach(v => { state.whitelist[v.id] = anyDisabled; });
    await saveWhitelist();
    renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
    flashStatus(anyDisabled ? 'All vendors enabled ✓' : 'All vendors disabled');
  });

  // Add custom vendor button
  document.getElementById('btnAddVendor').addEventListener('click', openVendorModal);

  // Import JSON
  document.getElementById('btnImportWL').addEventListener('click', () => {
    document.getElementById('wlFileInput').click();
  });
  document.getElementById('wlFileInput').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      // Accept either { whitelist: {...} } or raw { vendorId: bool } map
      if (data.whitelist) {
        state.whitelist = data.whitelist;
        state.customVendors = data.customVendors || state.customVendors;
      } else {
        state.whitelist = data;
      }
      await saveWhitelist();
      renderAllowList('');
      flashStatus('Whitelist imported ✓');
    } catch {
      flashStatus('Import failed — invalid JSON', true);
    }
    e.target.value = '';
  });

  // Export JSON
  document.getElementById('btnExportWL').addEventListener('click', () => {
    const payload = JSON.stringify({ whitelist: state.whitelist, customVendors: state.customVendors }, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = 'tagsentry-allowlist.json';
    a.click();
    URL.revokeObjectURL(url);
  });

  // Custom vendor modal
  document.getElementById('btnCancelVendor').addEventListener('click', () => {
    document.getElementById('modalVendor').hidden = true;
  });
  document.getElementById('modalVendor').addEventListener('click', e => {
    if (e.target === e.currentTarget) e.currentTarget.hidden = true;
  });
  document.getElementById('btnConfirmVendor').addEventListener('click', saveCustomVendor);

  // Builtin vendor view/edit modal
  initBuiltinVendorModal();
}

function renderAllowList(filter) {
  const container = document.getElementById('wlContent');
  container.innerHTML = '';

  // Merge builtins + custom
  const allVendors = [
    ...BUILTIN_VENDOR_IDS,
    ...state.customVendors.map(v => ({ ...v, isCustom: true })),
  ];

  const visible = filter
    ? allVendors.filter(v => v.name.toLowerCase().includes(filter) || v.category.toLowerCase().includes(filter))
    : allVendors;

  // Group by category
  const groups = {};
  visible.forEach(v => {
    if (!groups[v.category]) groups[v.category] = [];
    groups[v.category].push(v);
  });

  if (!Object.keys(groups).length) {
    container.innerHTML = `<div class="empty"><div class="empty-icon">🔍</div><div class="empty-title">No vendors match</div></div>`;
    // Still sync toggle button label
    syncWLToggleBtn(allVendors);
    return;
  }

  // Sync toggle-all button label based on current state
  syncWLToggleBtn(allVendors);

  Object.entries(groups).forEach(([cat, vendors]) => {
    const enabledCount  = vendors.filter(v => state.whitelist[v.id] !== false).length;
    const excludedCount = vendors.filter(v => state.exclusions?.[v.id] === true).length;

    const group = document.createElement('div');
    group.className = 'wl-group';

    const label = document.createElement('div');
    label.className = 'wl-group-label';
    label.innerHTML = `<span>${esc(cat)}</span>`;
    const badge = document.createElement('span');
    badge.className = `chip ${enabledCount === vendors.length ? 'chip-green' : enabledCount === 0 ? 'chip-grey' : 'chip-amber'}`;
    badge.style.fontSize = '7px';
    badge.textContent = `${enabledCount}/${vendors.length}`;
    label.appendChild(badge);
    group.appendChild(label);

    vendors.forEach(v => group.appendChild(buildWLItem(v)));
    container.appendChild(group);
  });
}

function syncWLToggleBtn(allVendors) {
  const btn = document.getElementById('btnWLToggleAll');
  if (!btn) return;
  const anyDisabled = allVendors.some(v => state.whitelist[v.id] === false);
  btn.textContent = anyDisabled ? 'Enable All' : 'Disable All';
  btn.classList.toggle('btn-danger', !anyDisabled); // red when about to disable all
  btn.classList.toggle('btn-success', anyDisabled); // green when about to enable all
}

function buildWLItem(v) {
  const enabled  = state.whitelist[v.id] !== false;
  const excluded = state.exclusions?.[v.id] === true;

  const item = document.createElement('div');
  item.className = `wl-item${enabled ? '' : ' disabled'}${excluded ? ' excluded' : ''}`;

  const icon = document.createElement('div');
  icon.className   = 'v-icon unknown';
  icon.style.cssText = 'width:18px;height:18px;font-size:7px;flex-shrink:0;';
  icon.textContent = v.name.slice(0, 2).toUpperCase();

  const nameEl = document.createElement('div');
  nameEl.className   = 'wl-name';
  nameEl.textContent = v.name;

  if (v.isCustom) {
    const badge = document.createElement('span');
    badge.className    = 'chip chip-teal';
    badge.style.cssText = 'font-size:7px;margin-left:5px;';
    badge.textContent   = 'Custom';
    nameEl.appendChild(badge);
  }

  if (state.vendorOverrides?.[v.id]) {
    const badge = document.createElement('span');
    badge.className    = 'chip chip-amber';
    badge.style.cssText = 'font-size:7px;margin-left:5px;';
    badge.textContent   = 'Modified';
    nameEl.appendChild(badge);
  }

  // ── Action buttons area ──────────────────────────────────────

  // Exclusion eye button — hides vendor from Live feed entirely (even when enabled)
  const eyeBtn = document.createElement('button');
  eyeBtn.className    = `btn btn-sm wl-eye-btn${excluded ? ' active' : ''}`;
  eyeBtn.title        = excluded ? 'Excluded from Live feed — click to show again' : 'Visible in Live feed — click to exclude';
  eyeBtn.textContent  = excluded ? '🙈' : '👁';
  eyeBtn.style.cssText = 'padding:1px 5px;font-size:10px;';
  eyeBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!state.exclusions) state.exclusions = {};
    state.exclusions[v.id] = !excluded;
    if (!state.exclusions[v.id]) delete state.exclusions[v.id];
    await saveWhitelist();
    renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
    // Re-apply live filters to immediately show/hide affected rows
    applyFilters(); updateStats(); updateBadges();
    flashStatus(state.exclusions[v.id] ? `Excluded: ${v.name}` : `Showing: ${v.name}`);
  });

  // Edit / Info button
  const editBtn = document.createElement('button');
  editBtn.className    = 'btn btn-sm';
  editBtn.style.cssText = 'padding:1px 5px;font-size:9px;';

  if (v.isCustom) {
    editBtn.textContent = '✎';
    editBtn.title       = 'Edit this custom vendor';
    editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openVendorModal(v);
    });
  } else {
    editBtn.textContent = 'ⓘ';
    editBtn.title       = 'View / edit this vendor definition';
    editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openBuiltinVendorModal(v);
    });
  }

  item.appendChild(icon);
  item.appendChild(nameEl);
  item.appendChild(eyeBtn);
  item.appendChild(editBtn);

  // Delete button — custom vendors only
  if (v.isCustom) {
    const del = document.createElement('button');
    del.className    = 'btn btn-sm btn-danger';
    del.style.cssText = 'padding:1px 5px;font-size:8px;';
    del.textContent  = '✕';
    del.title        = 'Remove this custom vendor';
    del.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Remove custom vendor "${v.name}"?`)) return;
      state.customVendors = state.customVendors.filter(cv => cv.id !== v.id);
      delete state.whitelist[v.id];
      delete state.exclusions[v.id];
      await saveWhitelist();
      renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
    });
    item.appendChild(del);
  }

  // Allow-list toggle (rightmost)
  const toggle   = document.createElement('label');
  toggle.className = 'toggle';
  const checkbox  = document.createElement('input');
  checkbox.type    = 'checkbox';
  checkbox.checked = enabled;
  checkbox.addEventListener('change', async () => {
    state.whitelist[v.id] = checkbox.checked;
    item.classList.toggle('disabled', !checkbox.checked);
    await saveWhitelist();
    renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
  });
  const span = document.createElement('span');
  toggle.appendChild(checkbox);
  toggle.appendChild(span);
  item.appendChild(toggle);

  return item;
}

async function saveWhitelist() {
  if (!state.exclusions) state.exclusions = {};
  await chrome.runtime.sendMessage({
    type:           'SAVE_SETTINGS',
    whitelist:      state.whitelist,
    customVendors:  state.customVendors,
    exclusions:     state.exclusions,
    vendorOverrides: state.vendorOverrides || {},
  });
}

// ── Custom vendor modal (add + edit) ──────────────────────────
// Called with no args → add mode.  Called with a vendor object → edit mode.
function openVendorModal(existing) {
  const modal    = document.getElementById('modalVendor');
  const titleEl  = modal.querySelector('h3') || modal.querySelector('.modal-title');
  const confirmBtn = document.getElementById('btnConfirmVendor');

  document.getElementById('vName').value     = existing?.name    || '';
  // Join multiple patterns with newlines for editing
  const pats = (existing?.patterns || []).map(p => typeof p === 'string' ? p : p.source).join('\n');
  document.getElementById('vPattern').value  = pats;
  document.getElementById('vCategory').value = existing?.category || 'Analytics';

  if (titleEl) titleEl.textContent = existing ? 'Edit Vendor' : 'Add Custom Vendor';

  // Store editing id so confirmVendor knows whether to insert or update
  modal.dataset.editingId = existing?.id || '';
  modal.hidden = false;
  document.getElementById('vName').focus();

  // Swap confirm handler
  confirmBtn.onclick = null;
  confirmBtn.addEventListener('click', saveCustomVendor, { once: true });
}

async function saveCustomVendor() {
  const modal    = document.getElementById('modalVendor');
  const editingId = modal.dataset.editingId || '';

  const name     = document.getElementById('vName').value.trim();
  const rawPat   = document.getElementById('vPattern').value.trim();
  const category = document.getElementById('vCategory').value;

  if (!name)   { flashStatus('Enter a vendor name', true); return; }
  if (!rawPat) { flashStatus('Enter at least one URL pattern', true); return; }

  // Support multiple patterns — one per line
  const patterns = rawPat.split('\n').map(s => s.trim()).filter(Boolean);

  if (editingId) {
    // Edit existing
    const idx = state.customVendors.findIndex(cv => cv.id === editingId);
    if (idx !== -1) {
      state.customVendors[idx] = { ...state.customVendors[idx], name, category, patterns };
    }
  } else {
    // Add new
    const id = 'custom_' + name.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Date.now();
    state.customVendors.push({ id, name, category, patterns, isCustom: true });
    state.whitelist[id] = true;
  }

  await saveWhitelist();
  modal.hidden = true;
  renderAllowList('');
  flashStatus(editingId ? `Updated: ${name} ✓` : `Added: ${name} ✓`);
}

// ── Builtin vendor view/edit modal ────────────────────────────
// Shows the vendor's current patterns (from overrides if any, else builtin).
// User can edit patterns and save as an override, or reset to builtin default.
function openBuiltinVendorModal(v) {
  const modal = document.getElementById('modalBuiltinVendor');
  if (!modal) { console.warn('modalBuiltinVendor not found'); return; }

  const builtinV  = BUILTIN_VENDOR_IDS.find(b => b.id === v.id);
  const override  = state.vendorOverrides?.[v.id];
  const currentPats = override?.patterns || builtinV?.patterns || [];
  const patsStr   = currentPats.map(p => typeof p === 'string' ? p : p.source).join('\n');

  modal.querySelector('#bvName').textContent    = v.name;
  modal.querySelector('#bvCategory').textContent = v.category;
  modal.querySelector('#bvPatterns').value      = patsStr;

  const resetBtn  = modal.querySelector('#btnResetBuiltinVendor');
  const noteEl    = modal.querySelector('#bvOverrideNote');
  if (resetBtn) resetBtn.disabled = !override;
  if (noteEl)   noteEl.hidden     = !override;

  modal.dataset.vendorId = v.id;
  modal.hidden = false;
}

// Init builtin vendor modal once (called during initAllowListTab)
function initBuiltinVendorModal() {
  const modal = document.getElementById('modalBuiltinVendor');
  if (!modal) return;

  modal.addEventListener('click', e => { if (e.target === modal) modal.hidden = true; });

  modal.querySelector('#btnCancelBuiltinVendor')?.addEventListener('click', () => {
    modal.hidden = true;
  });

  modal.querySelector('#btnSaveBuiltinVendor')?.addEventListener('click', async () => {
    const vid     = modal.dataset.vendorId;
    const rawPats = modal.querySelector('#bvPatterns').value.trim();
    if (!vid) return;

    const patterns = rawPats.split('\n').map(s => s.trim()).filter(Boolean);
    if (!patterns.length) { flashStatus('Enter at least one pattern', true); return; }

    if (!state.vendorOverrides) state.vendorOverrides = {};
    state.vendorOverrides[vid] = { patterns };
    await saveWhitelist();

    modal.hidden = true;
    renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
    flashStatus('Vendor definition updated ✓');
  });

  modal.querySelector('#btnResetBuiltinVendor')?.addEventListener('click', async () => {
    const vid = modal.dataset.vendorId;
    if (!vid) return;
    if (!confirm('Reset this vendor to the built-in default?')) return;

    if (state.vendorOverrides) delete state.vendorOverrides[vid];
    await saveWhitelist();

    modal.hidden = true;
    renderAllowList(document.getElementById('wlSearch').value.trim().toLowerCase());
    flashStatus('Reset to default ✓');
  });
}

// ── Legacy alias kept so old code still compiles ──────────────
function addCustomVendor() { saveCustomVendor(); }



// ══════════════════════════════════════════════════════════════
// STEP 5 — EXPORT TAB
// ══════════════════════════════════════════════════════════════

function initExportTab() {
  // Format card selection
  document.querySelectorAll('.export-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.export-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const fmt = card.dataset.fmt.toUpperCase();
      document.getElementById('btnExport').textContent = `📤 Download ${fmt}`;
    });
  });

  document.getElementById('btnExport').addEventListener('click', runExport);
}

async function runExport() {
  const fmtCard = document.querySelector('.export-card.selected');
  const fmt     = fmtCard?.dataset.fmt || 'csv';
  const redact  = document.getElementById('expRedact').checked;
  const inclRaw = document.getElementById('expRaw').checked;
  const inclDiff= document.getElementById('expDiff').checked;

  const requests = prepareExportRequests(state.requests, redact);

  let blob, filename;
  switch (fmt) {
    case 'csv':  ({ blob, filename } = exportCSV(requests));  break;
    case 'json': ({ blob, filename } = exportJSON(requests, inclRaw, inclDiff)); break;
    case 'html': ({ blob, filename } = await exportHTML(requests, inclDiff)); break;
    case 'har':  ({ blob, filename } = exportHAR(requests));  break;
    default:     ({ blob, filename } = exportCSV(requests));
  }

  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href    = url;
  a.download= filename;
  a.click();
  URL.revokeObjectURL(url);

  const msg = document.getElementById('exportMsg');
  msg.textContent = `✓ Downloaded ${filename}`;
  setTimeout(() => { msg.textContent = ''; }, 3000);
}

function prepareExportRequests(requests, redact) {
  if (!redact) return requests;
  return requests.map(r => {
    const piiKeys = new Set((r.piiFindings || []).map(f => f.param));
    const redactObj = (obj) => {
      const out = {};
      Object.entries(obj || {}).forEach(([k, v]) => {
        out[k] = piiKeys.has(k) ? '[REDACTED]' : v;
      });
      return out;
    };
    return { ...r, params: redactObj(r.params), bodyParams: redactObj(r.bodyParams) };
  });
}

function exportCSV(requests) {
  const cols = ['timestamp','vendor','category','eventName','hostname','statusCode','piiCount','url'];
  const rows = [cols.join(',')];
  requests.forEach(r => {
    const row = [
      new Date(r.timestamp).toISOString(),
      csvCell(r.vendor?.name || ''),
      csvCell(r.vendor?.category || ''),
      csvCell(r.eventName || ''),
      csvCell(r.hostname || ''),
      r.statusCode || '',
      r.piiFindings?.length || 0,
      csvCell(r.url || ''),
    ];
    rows.push(row.join(','));
  });
  return {
    blob: new Blob([rows.join('\n')], { type: 'text/csv' }),
    filename: `tagsentry-${Date.now()}.csv`,
  };
}

function csvCell(val) {
  const s = String(val || '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function exportJSON(requests, inclRaw, inclDiff) {
  const payload = {
    exported:  new Date().toISOString(),
    tagCount:  requests.length,
    piiCount:  requests.reduce((n, r) => n + (r.piiFindings?.length || 0), 0),
    requests:  requests.map(r => {
      const out = {
        id:         r.id,
        timestamp:  new Date(r.timestamp).toISOString(),
        vendor:     r.vendor?.name || null,
        category:   r.vendor?.category || null,
        eventName:  r.eventName,
        hostname:   r.hostname,
        statusCode: r.statusCode,
        params:     r.params,
        bodyParams: r.bodyParams,
        piiFindings:r.piiFindings,
      };
      if (inclRaw) out.rawUrl = r.rawUrl || r.url;
      return out;
    }),
  };
  return {
    blob: new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }),
    filename: `tagsentry-${Date.now()}.json`,
  };
}

async function exportHTML(requests, inclDiff) {
  let diffSection = '';

  if (inclDiff && state.baselineId) {
    const res = await chrome.runtime.sendMessage({ type: 'GET_SESSIONS' });
    const sessions = res?.sessions || [];
    const baseline = sessions.find(s => s.id === state.baselineId);
    if (baseline) {
      // Build a minimal session object from current live requests
      const liveSession = {
        id: 'live', name: 'Current Session',
        requests: state.requests, pageUrl: state.requests[0]?.url || ''
      };
      // We can't call background diff from here easily, so note it
      diffSection = `<p style="color:#888">Diff vs baseline "${esc(baseline.name)}" — open Diff tab for full comparison.</p>`;
    }
  }

  const rows = requests.map(r => `
    <tr>
      <td>${new Date(r.timestamp).toLocaleTimeString()}</td>
      <td>${esc(r.vendor?.name || '—')}</td>
      <td>${esc(r.vendor?.category || '—')}</td>
      <td>${esc(r.eventName || '—')}</td>
      <td>${esc(r.hostname)}</td>
      <td>${r.statusCode}</td>
      <td style="color:${r.piiFindings?.length ? '#f87171' : '#4ade80'}">${r.piiFindings?.length || 0}</td>
    </tr>`).join('');

  const piiRows = requests.flatMap(r =>
    (r.piiFindings || []).map(f => `
      <tr>
        <td style="color:#f87171;font-weight:600">${esc(f.severity)}</td>
        <td>${esc(f.param)}</td>
        <td style="color:#888">[REDACTED]</td>
        <td>${esc(f.patternName)}</td>
        <td>${esc(r.vendor?.name || r.hostname)}</td>
      </tr>`)
  ).join('');

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>TagSentry Audit Report</title>
<style>
  body { font-family: -apple-system, sans-serif; background:#13121a; color:#e0dff0; margin:0; padding:24px; }
  h1   { font-size:24px; font-weight:700; margin-bottom:4px; }
  h2   { font-size:14px; font-weight:600; margin:20px 0 8px; color:#9090b0; text-transform:uppercase; letter-spacing:.08em; }
  .meta{ font-size:12px; color:#5c5b74; margin-bottom:24px; font-family:monospace; }
  .stat-row { display:flex; gap:16px; margin-bottom:20px; }
  .stat { background:#1c1b28; border:1px solid #2a2938; border-radius:8px; padding:12px 18px; text-align:center; }
  .stat strong { display:block; font-size:28px; font-weight:600; }
  .stat span   { font-size:11px; color:#5c5b74; text-transform:uppercase; letter-spacing:.08em; font-family:monospace; }
  table { width:100%; border-collapse:collapse; margin-bottom:24px; }
  th    { background:#1c1b28; font-family:monospace; font-size:9px; text-transform:uppercase; letter-spacing:.08em; color:#5c5b74; padding:6px 10px; text-align:left; border:1px solid #2a2938; }
  td    { padding:6px 10px; border:1px solid #1e1d2a; font-size:12px; vertical-align:top; background:#0e0d16; }
  tr:hover td { background:#13121a; }
  .badge-pii { background:rgba(239,68,68,.15); color:#f87171; border-radius:4px; padding:1px 6px; font-size:10px; font-family:monospace; }
</style>
</head>
<body>
<h1>🏷️ TagSentry Audit Report</h1>
<div class="meta">Generated: ${new Date().toISOString()} · TagSentry v1.4.0</div>

<div class="stat-row">
  <div class="stat"><strong>${requests.length}</strong><span>Total Tags</span></div>
  <div class="stat"><strong style="color:#22c55e">${requests.filter(r => r.isWhitelisted && !r.piiFindings?.length).length}</strong><span>OK</span></div>
  <div class="stat"><strong style="color:#f59e0b">${requests.filter(r => !r.isWhitelisted && !r.piiFindings?.length).length}</strong><span>Unlisted</span></div>
  <div class="stat"><strong style="color:#ef4444">${requests.reduce((n,r) => n + (r.piiFindings?.length||0), 0)}</strong><span>PII Issues</span></div>
</div>

${diffSection}

<h2>Tag Requests</h2>
<table>
  <thead><tr><th>Time</th><th>Vendor</th><th>Category</th><th>Event</th><th>Hostname</th><th>Status</th><th>PII</th></tr></thead>
  <tbody>${rows}</tbody>
</table>

${piiRows ? `<h2>PII Findings</h2>
<table>
  <thead><tr><th>Severity</th><th>Parameter</th><th>Value</th><th>Pattern</th><th>Tag</th></tr></thead>
  <tbody>${piiRows}</tbody>
</table>` : ''}

</body></html>`;

  return {
    blob: new Blob([html], { type: 'text/html' }),
    filename: `tagsentry-report-${Date.now()}.html`,
  };
}

function exportHAR(requests) {
  const har = {
    log: {
      version: '1.2',
      creator: { name: 'TagSentry', version: '1.3.0' },
      entries: requests.map(r => ({
        startedDateTime: new Date(r.timestamp).toISOString(),
        time: 0,
        request: {
          method: r.method || 'GET',
          url: r.rawUrl || r.url || '',
          httpVersion: 'HTTP/1.1',
          cookies: [],
          headers: [],
          queryString: Object.entries(r.params || {}).map(([n, v]) => ({ name: n, value: String(v) })),
          postData: r.bodyParams && Object.keys(r.bodyParams).length
            ? { mimeType: 'application/x-www-form-urlencoded', text: JSON.stringify(r.bodyParams) }
            : undefined,
          headersSize: -1,
          bodySize: -1,
        },
        response: {
          status: r.statusCode || 0,
          statusText: '',
          httpVersion: 'HTTP/1.1',
          cookies: [],
          headers: [],
          content: { size: -1, mimeType: '' },
          redirectURL: '',
          headersSize: -1,
          bodySize: -1,
        },
        cache: {},
        timings: { send: 0, wait: 0, receive: 0 },
        comment: r.vendor ? `${r.vendor.name} — ${r.eventName || ''}` : '',
      })),
    },
  };

  return {
    blob: new Blob([JSON.stringify(har, null, 2)], { type: 'application/json' }),
    filename: `tagsentry-${Date.now()}.har`,
  };
}

// ── Final export ──────────────────────────────────────────────
window.__TS = {
  state, switchTab, applyFilters, updateStats, updateBadges,
  fmtDate, fmtTime, loadSessions, populateDiffSelects,
  renderPIITab, renderAllowList,
};

// ══════════════════════════════════════════════════════════════
// STEP 6 — SETTINGS TAB
// ══════════════════════════════════════════════════════════════

async function initSettingsTab() {
  // Load current settings from background
  const res = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
  state.settings       = res?.settings       || {};
  state.exclusions     = res?.exclusions     || {};
  state.vendorOverrides= res?.vendorOverrides || {};
  applySettingsToUI(state.settings);

  // Save
  document.getElementById('btnSaveSettings').addEventListener('click', saveSettings);

  // Backup
  document.getElementById('btnBackup').addEventListener('click', async () => {
    const res = await chrome.runtime.sendMessage({ type: 'BACKUP' });
    if (!res?.backup) { flashStatus('Backup failed', true); return; }
    const blob = new Blob([res.backup], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `tagsentry-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    flashStatus('Backup downloaded ✓');
  });

  // Restore
  document.getElementById('btnRestore').addEventListener('click', () => {
    document.getElementById('restoreFile').click();
  });
  document.getElementById('restoreFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!confirm('Restore will overwrite all current sessions, settings, and whitelist. Continue?')) return;
    const json = await file.text();
    const res  = await chrome.runtime.sendMessage({ type: 'RESTORE', json });
    if (res?.ok) {
      flashStatus('Restore complete ✓');
      // Reload everything
      const fresh = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
      state.settings      = fresh?.settings      || {};
      state.whitelist     = fresh?.whitelist     || {};
      state.customVendors = fresh?.customVendors || [];
      applySettingsToUI(state.settings);
      await loadSessions();
      renderAllowList('');
    } else {
      flashStatus(res?.error || 'Restore failed', true);
    }
    e.target.value = '';
  });

  // Inject live version from manifest — never stale, regardless of what HTML says
  try {
    const { version } = chrome.runtime.getManifest();
    const badge = document.querySelector('.version-badge');
    if (badge) badge.textContent = `TagSentry v${version} · MV3 Chrome Extension`;
  } catch { /* extension context unavailable */ }

  // Clear all
  document.getElementById('btnClearAll').addEventListener('click', async () => {
    if (!confirm('This will permanently delete all sessions, settings, and whitelist data. Are you sure?')) return;
    await chrome.runtime.sendMessage({ type: 'CLEAR_ALL_DATA' });
    state.sessions      = [];
    state.requests      = [];
    state.filtered      = [];
    state.selected      = null;
    state.whitelist     = {};
    state.customVendors = [];
    state.settings      = {};
    applySettingsToUI({});
    renderTagList();
    updateStats();
    updateBadges();
    await loadSessions();
    renderAllowList('');
    flashStatus('All data cleared');
  });
}

function applySettingsToUI(s) {
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.type === 'checkbox') el.checked = val !== false && val !== undefined ? !!val : el.defaultChecked;
    else el.value = val ?? el.defaultValue;
  };

  set('setAutoStart',  s.autoStart      !== false);
  set('setKnownOnly',  !!s.knownVendorsOnly);
  set('setClearNav',   !!s.clearOnNavigate);
  set('setMaxSess',    s.maxSessions    || 50);

  // piiPatterns: [] = all off, null = all on (legacy), [ids] = specific set
  // For new installs defaultSettings() returns [] so all boxes start unchecked.
  const piiEnabled = s.piiPatterns;
  const allOff = Array.isArray(piiEnabled) && piiEnabled.length === 0;
  const piiIds = allOff ? [] : (piiEnabled || ['email','phone','ip','ssn','cc','dob']);
  set('piiEmail', piiIds.includes('email'));
  set('piiPhone', piiIds.includes('phone'));
  set('piiIP',    piiIds.includes('ip'));
  set('piiSSN',   piiIds.includes('ssn'));
  set('piiCC',    piiIds.includes('cc'));
  set('piiDOB',   piiIds.includes('dob'));

  // Render custom PII patterns list
  renderCustomPiiPatterns(s.customPiiPatterns || []);
}

async function saveSettings() {
  const piiPatterns = ['email','phone','ip','ssn','cc','dob'].filter(id => {
    const el = document.getElementById('pii' + id.charAt(0).toUpperCase() + id.slice(1));
    return el?.checked;
  });

  const settings = {
    autoStart:          document.getElementById('setAutoStart').checked,
    knownVendorsOnly:   document.getElementById('setKnownOnly').checked,
    clearOnNavigate:    document.getElementById('setClearNav').checked,
    maxSessions:        parseInt(document.getElementById('setMaxSess').value, 10) || 50,
    // [] = explicitly none, null was the old "all on" sentinel — we no longer emit null
    piiPatterns:        piiPatterns,
    customPiiPatterns:  state.settings.customPiiPatterns || [],
  };

  const res = await chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings });
  if (res?.ok) {
    state.settings = settings;
    flashStatus('Settings saved ✓');
  } else {
    flashStatus('Save failed', true);
  }
}

// ══════════════════════════════════════════════════════════════
// CUSTOM PII PATTERN EDITOR
// ══════════════════════════════════════════════════════════════

function initCustomPiiPatterns() {
  const addBtn = document.getElementById('btnAddPiiPattern');
  if (addBtn) addBtn.addEventListener('click', () => openPiiPatternModal(null));

  const cancelBtn = document.getElementById('btnCancelPiiPattern');
  if (cancelBtn) cancelBtn.addEventListener('click', () => {
    document.getElementById('modalPiiPattern').hidden = true;
  });

  const confirmBtn = document.getElementById('btnConfirmPiiPattern');
  if (confirmBtn) confirmBtn.addEventListener('click', saveCustomPiiPattern);

  // Live regex test
  const testInput = document.getElementById('piiPatternTest');
  const regexInput = document.getElementById('piiPatternRegex');
  const testResult = document.getElementById('piiPatternTestResult');
  if (testInput && regexInput && testResult) {
    function doTest() {
      const rawPattern = regexInput.value.trim();
      const testVal    = testInput.value;
      if (!rawPattern || !testVal) { testResult.textContent = ''; return; }
      try {
        const rx = new RegExp(rawPattern, 'i');
        const matches = rx.test(testVal);
        testResult.textContent  = matches ? '✓ Match' : '✗ No match';
        testResult.style.color  = matches ? 'var(--green)' : 'var(--text3)';
        testResult.style.background = matches ? 'var(--green-lt)' : 'var(--bg3)';
      } catch {
        testResult.textContent  = '✗ Invalid';
        testResult.style.color  = 'var(--red)';
        testResult.style.background = 'var(--red-lt)';
      }
    }
    testInput.addEventListener('input', doTest);
    regexInput.addEventListener('input', doTest);
  }
}

let _editingPiiIdx = null;

function openPiiPatternModal(idx) {
  _editingPiiIdx = idx;
  const patterns = state.settings.customPiiPatterns || [];
  const p = idx !== null ? patterns[idx] : null;

  document.getElementById('piiModalTitle').textContent = p ? 'Edit PII Pattern' : 'Add Custom PII Pattern';
  document.getElementById('piiPatternName').value      = p?.name    || '';
  document.getElementById('piiPatternRegex').value     = p?.pattern || '';
  document.getElementById('piiPatternSeverity').value  = p?.severity || 'MEDIUM';
  document.getElementById('piiPatternTest').value      = '';
  document.getElementById('piiPatternTestResult').textContent = '';
  document.getElementById('piiPatternDesc').textContent = p?.description || '';
  document.getElementById('modalPiiPattern').hidden = false;
  document.getElementById('piiPatternName').focus();
}

async function saveCustomPiiPattern() {
  const name     = document.getElementById('piiPatternName').value.trim();
  const pattern  = document.getElementById('piiPatternRegex').value.trim();
  const severity = document.getElementById('piiPatternSeverity').value;

  if (!name)    { flashStatus('Enter a pattern name', true); return; }
  if (!pattern) { flashStatus('Enter a regex pattern', true); return; }

  // Validate regex
  try { new RegExp(pattern, 'i'); } catch {
    flashStatus('Invalid regex pattern', true);
    return;
  }

  const id = 'custom_pii_' + name.toLowerCase().replace(/[^a-z0-9]/g,'_');
  const entry = { id, name, pattern, severity, flags: 'i' };

  if (!state.settings.customPiiPatterns) state.settings.customPiiPatterns = [];

  if (_editingPiiIdx !== null) {
    state.settings.customPiiPatterns[_editingPiiIdx] = entry;
  } else {
    state.settings.customPiiPatterns.push(entry);
  }

  document.getElementById('modalPiiPattern').hidden = true;
  renderCustomPiiPatterns(state.settings.customPiiPatterns);
  await saveSettings();
  flashStatus(`Pattern "${name}" saved ✓`);
}

function renderCustomPiiPatterns(patterns) {
  const list = document.getElementById('customPiiList');
  if (!list) return;
  list.innerHTML = '';

  if (!patterns || !patterns.length) {
    list.innerHTML = '<div style="font-family:var(--mono);font-size:10px;color:var(--text4);padding:6px 0;">No custom patterns defined.</div>';
    return;
  }

  patterns.forEach((p, i) => {
    const row = document.createElement('div');
    row.className = 'option-row';
    row.style.flexWrap = 'wrap';
    row.style.gap = '4px';

    const info = document.createElement('div');
    info.style.flex = '1';
    info.style.minWidth = '0';

    const nameEl = document.createElement('div');
    nameEl.className  = 'opt-label';
    nameEl.textContent = p.name;

    const regexEl = document.createElement('div');
    regexEl.className   = 'opt-sub';
    regexEl.style.fontFamily = 'var(--mono)';
    regexEl.textContent = `/${p.pattern}/i  ·  ${p.severity}`;

    info.appendChild(nameEl);
    info.appendChild(regexEl);

    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.gap = '4px';

    const editBtn = document.createElement('button');
    editBtn.className   = 'btn btn-sm';
    editBtn.textContent = '✏ Edit';
    editBtn.addEventListener('click', () => openPiiPatternModal(i));

    const delBtn = document.createElement('button');
    delBtn.className   = 'btn btn-sm btn-danger';
    delBtn.textContent = '🗑';
    delBtn.addEventListener('click', async () => {
      state.settings.customPiiPatterns.splice(i, 1);
      renderCustomPiiPatterns(state.settings.customPiiPatterns);
      await saveSettings();
      flashStatus(`Pattern removed`);
    });

    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    row.appendChild(info);
    row.appendChild(actions);
    list.appendChild(row);
  });
}

// ══════════════════════════════════════════════════════════════
// FEATURE ADDITIONS — step 6 updates
// ══════════════════════════════════════════════════════════════

// ── 5. Body section with expandable [object Object] ───────────
function renderBodySection(container, params, piiFindings) {
  const keys = Object.keys(params);
  if (!keys.length) {
    const el = document.createElement('div');
    el.className = 'detail-empty';
    el.textContent = 'No body parameters found.';
    container.appendChild(el);
    return;
  }

  const piiParams = new Set(piiFindings.map(f => f.param));

  keys.forEach(key => {
    const val = params[key];
    const isPII = piiParams.has(key);

    const row = document.createElement('div');
    row.className = 'param-row';

    const k = document.createElement('div');
    k.className   = 'p-key';
    k.textContent = key;

    const v = document.createElement('div');
    v.className = isPII ? 'p-val pii-val' : 'p-val';

    // If value is an object/array, render as collapsible JSON tree
    if (val !== null && typeof val === 'object') {
      v.appendChild(buildJsonNode(val, true));
    } else {
      // Try to parse stringified JSON
      if (typeof val === 'string' && (val.startsWith('{') || val.startsWith('['))) {
        try {
          const parsed = JSON.parse(val);
          v.appendChild(buildJsonNode(parsed, true));
        } catch {
          v.textContent = String(val);
        }
      } else {
        v.textContent = String(val ?? '');
      }
    }

    if (isPII) {
      const badge = document.createElement('span');
      badge.className   = 'pii-inline';
      badge.textContent = '⚠ PII';
      v.appendChild(badge);
    }

    row.appendChild(k);
    row.appendChild(v);
    container.appendChild(row);
  });
}

// Build a recursive JSON tree node
function buildJsonNode(val, startOpen = false) {
  const wrap = document.createElement('span');
  wrap.className = 'json-node';

  if (val === null) {
    wrap.innerHTML = '<span class="json-null">null</span>';
    return wrap;
  }

  if (typeof val !== 'object') {
    const cls = typeof val === 'string' ? 'json-str'
              : typeof val === 'boolean' ? 'json-bool'
              : 'json-num';
    const display = typeof val === 'string' ? `"${val}"` : String(val);
    const span = document.createElement('span');
    span.className   = cls;
    span.textContent = display;
    wrap.appendChild(span);
    return wrap;
  }

  const isArray = Array.isArray(val);
  const entries = isArray ? val.map((v, i) => [String(i), v]) : Object.entries(val);
  const count   = entries.length;
  const preview = isArray ? `[${count}]` : `{${count}}`;

  // Toggle button
  const toggle = document.createElement('button');
  toggle.className = 'json-toggle';

  const caret = document.createElement('span');
  caret.className   = 'json-caret' + (startOpen ? ' open' : '');
  caret.textContent = '▶';

  const label = document.createElement('span');
  label.textContent = preview;

  toggle.appendChild(caret);
  toggle.appendChild(label);
  wrap.appendChild(toggle);

  // Children container
  const children = document.createElement('div');
  children.className = 'json-children';
  children.hidden    = !startOpen;

  entries.forEach(([k, v]) => {
    const line = document.createElement('div');

    const keyEl = document.createElement('span');
    keyEl.className   = 'json-key';
    keyEl.textContent = isArray ? '' : `${k}: `;
    line.appendChild(keyEl);

    line.appendChild(buildJsonNode(v, false));
    children.appendChild(line);
  });

  wrap.appendChild(children);

  toggle.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = children.hidden;
    children.hidden   = !open;
    caret.classList.toggle('open', open);
  });

  return wrap;
}

// ── 2. KEYBOARD NAVIGATION ────────────────────────────────────
function initKeyboardNav() {
  document.addEventListener('keydown', (e) => {
    if (state.activeTab !== 'live') return;

    // Don't intercept when typing in an input
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const len = state.filtered.length;
      if (!len) return;

      if (e.key === 'ArrowDown') {
        state.kbIndex = Math.min(state.kbIndex + 1, len - 1);
      } else {
        state.kbIndex = Math.max(state.kbIndex - 1, 0);
      }

      const entry = state.filtered[state.kbIndex];
      if (entry) {
        selectEntry(entry);
        scrollRowIntoView(entry.id);
      }
    }

    if (e.key === 'Escape') {
      hideDetail();
      state.kbIndex = -1;
    }

    // Focus search with /
    if (e.key === '/' && !e.ctrlKey && !e.metaKey) {
      const si = document.getElementById('searchInput');
      if (si && document.activeElement !== si) {
        e.preventDefault();
        si.focus();
        si.select();
      }
    }
  });

  // Also handle arrow keys when the tag list itself has focus
  document.querySelector('.tag-list-wrap')?.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') e.preventDefault();
  });
}

function scrollRowIntoView(entryId) {
  const row = document.querySelector(`.tag-row[data-id="${entryId}"]`);
  if (row) row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

// Keep kbIndex in sync when entries are selected by click
const _origSelectEntry = selectEntry;
// We patch it by wrapping after declaration — done inline below

// ── 3. DETAIL PANEL RESIZE ────────────────────────────────────
function initDetailResize() {
  const handle = document.getElementById('detailResizeHandle');
  const panel  = document.getElementById('detailPanel');
  const sizeBtn= document.getElementById('dSizeBtn');

  if (!handle || !panel) return;

  let startY = 0, startH = 0, dragging = false;

  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    dragging = true;
    startY   = e.clientY;
    startH   = panel.offsetHeight;
    handle.classList.add('dragging');
    document.body.style.cursor = 'ns-resize';
    document.body.style.userSelect = 'none';
  });

  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const delta  = startY - e.clientY; // drag up = increase height
    const newH   = Math.max(120, Math.min(window.innerHeight * 0.85, startH + delta));
    panel.style.height = newH + 'px';
    state.detailHeight  = newH;
  });

  document.addEventListener('mouseup', () => {
    if (!dragging) return;
    dragging = false;
    handle.classList.remove('dragging');
    document.body.style.cursor   = '';
    document.body.style.userSelect = '';
  });

  // Expand/collapse toggle button
  if (sizeBtn) {
    sizeBtn.addEventListener('click', () => {
      state.detailExpanded = !state.detailExpanded;
      if (state.detailExpanded) {
        panel.style.height = '85vh';
        sizeBtn.textContent = '⤡';
        sizeBtn.classList.add('expanded');
        sizeBtn.title = 'Collapse detail panel';
      } else {
        panel.style.height = (state.detailHeight || 300) + 'px';
        sizeBtn.textContent = '⤢';
        sizeBtn.classList.remove('expanded');
        sizeBtn.title = 'Expand detail panel';
      }
    });
  }
}

// ── 1. APPEARANCE — light/dark theme + font size ──────────────
function initAppearance() {
  // Load saved preferences
  chrome.storage.local.get('appearance', ({ appearance }) => {
    if (appearance) {
      state.appearance = { ...state.appearance, ...appearance };
    }
    applyAppearance(state.appearance, false);
    syncAppearanceUI(state.appearance);
  });

  // Theme buttons (in settings panel)
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.appearance.theme = btn.dataset.themeVal;
      applyAppearance(state.appearance);
      document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  // Font size buttons
  document.querySelectorAll('.fs-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.appearance.fontSize = parseInt(btn.dataset.fs, 10);
      applyAppearance(state.appearance);
      document.querySelectorAll('.fs-btn').forEach(b => b.classList.toggle('active', b === btn));
    });
  });
}

function applyAppearance(ap, save = true) {
  document.documentElement.dataset.theme = ap.theme || 'light';
  document.documentElement.style.setProperty('--fs-base', (ap.fontSize || 14) + 'px');
  if (save) chrome.storage.local.set({ appearance: ap });
}

function syncAppearanceUI(ap) {
  document.querySelectorAll('.theme-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.themeVal === ap.theme);
  });
  document.querySelectorAll('.fs-btn').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.fs, 10) === ap.fontSize);
  });
}

// ── Patch selectEntry to keep kbIndex in sync ─────────────────
// Wrap the existing selectEntry so clicks also update kbIndex
(function patchSelectEntry() {
  const orig = selectEntry;
  // We can't reassign a function declaration, so we use an event approach:
  // The tag-row click fires selectEntry directly. Instead we hook addTagRow's
  // listener. Since addTagRow is already defined, we patch at the list level.
  document.getElementById('tagList')?.addEventListener('click', (e) => {
    const row = e.target.closest('.tag-row');
    if (!row) return;
    const id  = row.dataset.id;
    const idx = state.filtered.findIndex(r => r.id === id);
    if (idx !== -1) state.kbIndex = idx;
  }, true); // capture phase so it runs before individual row listeners
})();
